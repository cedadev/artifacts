import pyncl, array, cdms, os, string, basic_utils
import Numeric
try:
  from config import work_dir
except:
  work_dir = "/tmp/"
##
##

titles_fontht = 22
xytitles_fontht = 18
ticklabel_fontht = 18
ticklength = 0.015

#- Set font to use for the ticklabels (ticklabel_font) and the
#  titles (titles_font):

ticklabel_font = 4
titles_font = 4

#- Set conversion factor to multiply font height coordinates by
#  to obtain the value in normalized coordinates.  This is set
#  by trial-and-error:

fontht2norm = 0.00075

class plot:

  def __init__( self, geometry=[400,600,10,10]):
    self.a=pyncl.Ncl(NCARG_ROOT="/usr/local")
    ## this command messes up positioning ##
    self.geometry = geometry
    self.xvals_htag = 0
    self.reset()
    self.xmtic=0
    self.bbllx = 0.15
    self.bblly = 0.45
    self.bburx = 0.85
    self.bbury = 0.85
    self.xdict = {}
#
# set x, y ranges to undefined
#
    self.set_xrange( 0 )
    self.set_yrange( 0 )

    self.subtitles = None
    self.poly_init=0
    self.line_init=0
    self.colours = '(/"white", "black", "red", "green", "blue", \
              "cyan", "yellow", "orange", \
              "(/.9,.9,.9/)", \
              /)'

    self.a('txres = True' )
    self.set_ncl( 'txres', 'txFontHeightF', 0.015 )
# justification of text
    self.set_ncl( 'txres', 'txJust', 'BottomLeft' )
    self.set_ncl( 'txres', 'txFontColor', 'black' )

  def set_ncl( self, flag, var, val, raw=0 ):
     if type( val ) == type([]):
      if type(val[0]) != type( 'x' ):
        self.a( '%s@%s = (/ %s /)' % (flag,var,string.join( map( lambda x: str(x), val ),', ' ) ) )
      else:
        print 'not ready for this'
        raise 'arghhhh'
     else:
      if raw == 0 and type( val ) == type( 'x' ):
        self.a( '%s@%s = "%s"' % (flag,var,val) )
      else:
        self.a( '%s@%s = %s' % (flag,var,val) )

  def text( self, val, x, y, coords='ndc', plot='map' ):
    print '>> text',val, x, y 
    if coords == 'ndc':
      self.a('gsn_text_ndc(wks,"%s",%s,%s,txres)' % ( val, x, y ) )
    elif coords == 'user':
      self.a('gsn_text(wks,%s,"%s",%s,%s,txres)' % ( plot, val, x, y ) )

  def set_yrange( self, yy, new=1 ):
    if type(yy) != type([]) or len(yy) < 2:
      self.data_yhi = None
      self.data_ylo = None
    elif new == 1:
      self.data_yhi = max(yy)
      self.data_ylo = min(yy)
    else:
      self.data_yhi = max( max(yy), self.data_yhi )
      self.data_ylo = min( min(yy), self.data_ylo )

  def yaxis( self, yy, name='undefined' ):
    self.yax = cdms.createAxis( yy, id=name )

  def xaxis( self, yy, name='undefined' ):
    self.xax = cdms.createAxis( yy, id=name )

  def show( self ):
    self.a('frame(wks)')
    self.a.nclrun()

  def set_subtitle( self, subt ):
    title_xpos = 0.2
    if type( subt ) == type( [] ):
        tts = subt
        yy = 0.25
        dy = -0.034
        xoffs = [0.,0.,0.]
        fonth =  0.015
    elif type( subt ) == type( {} ):
        xoffs = subt.get( 'xoffs', [0.,0.,0.] )
        self.set_ncl( 'txres', 'txPosXF',  subt.get( 'xx', 0.3 ) )
        tts = subt.get( 'titles', ['no titles given'] )
        yy = subt.get( 'yy', 0.25 )
        dy = subt.get( 'dy', -0.034 )
        fonth = subt.get( 'fonth', 0.015 )

    self.set_ncl( 'txres', 'txFontHeightF', fonth )
    for l in tts:
        yy += dy
        if type(l) == type( ' ' ):
          self.set_ncl( 'txres', 'txPosXF', title_xpos )
#  the x component has no effect -- over-ridden by txPosXF above
          self.text( l, 0.7, yy )
        else:
          for k in range(len(l)):
            self.set_ncl( 'txres', 'txPosXF', title_xpos + xoffs[k] )
            self.text( l[k], 0.7, yy )


###############################################################
##  yy: array to be plotted
## opts: dictionary of options
## pos: list specifying position on page
## yrange: range of y-axis
## clear=1: option to clear page (0 to not clear page)
###############################################################
  def plot( self, yy, x=False, opts={}, pos=[], \
       xrange=[0], yrange=[0], clear=1, line_width=1., new_xy=None, \
       anno=None,
       plotdev='x11', 
       anno_font_height=0.015,
       anno_font_type=21, 
       min_value=-900.,
       yaxis_name='Temperature anomaly [K]',
       do_plot=0, colour="black", dash=0 ):

    self.npl=1
    self.min_value = min_value
    self.a('res=True')
    self.a('txres = True' )
    self.a('anres = True' )
    self.anno_font_height = anno_font_height
    self.anno_font_type = anno_font_type
#
# first colour is background
#
    self.p_colours = ["white",colour ]
    self.p_colours = [colour ]

    self.a.plotdev = plotdev
    self.a.fontname = 'courier'
    
    title = opts.get( 'title', ' ' )
    self.line_colors=[1,2,3,4,5,6,7,8]
    self.line_thicknesses=[line_width]
    self.line_dash_pattern=[dash]
    self.line_thickness_def=line_width
    if anno != None:
      self.plot_annotate = [anno]
    else:
      self.plot_annotate = []
    self.yaxis_name = yaxis_name

    self.set_ncl('res', 'tiMainString', title  )
    self.set_ncl('res', 'tiMainFont',  "Times-Bold" )
    self.set_ncl('res', 'tmBorderThicknessF', 2.)
##
## don't know why these fonts come out different sizes.
##
    self.set_ncl('res', 'tmXBLabelFontHeightF', 0.015)
    self.set_ncl('res', 'tmYLLabelFontHeightF', 0.015)

## height and width in inches.
    ## following doesn't appear to do anything.

    if plotdev in ['pdf','ps']:
      self.set_ncl('res', 'gsnPaperWidth', 12.)
      self.set_ncl('res', 'gsnPaperHeight', 9.)

    ## gsnMaximize: this rotates the image to use full paper area --
    ## but puts some of it outside the paper area.
    ##self.set_ncl('res', 'gsnMaximize', True)

    self.set_ncl( 'res', 'xyLineColors', self.line_colors )

    if opts.has_key( 'subtitle' ):
      self.subtitles = opts['subtitle']
    if opts.has_key( 'yax' ):
      self.yaxis_name = opts['yax']
    self.xaxis_name = opts.get( 'xax', 'Year' )
      
    if len(yrange) == 2:
      print '>>>>>> set_yrange'
      self.set_yrange( yrange )
##
##
    self.ydata = yy
    if x:
        self.xdict[self.npl-1] = x

    if do_plot == 1:
      self.create_plot()

  def add_subtitle(self,subt,start=0,colour=1):

    if self.subtitle_k == 0 or start==1:
      self.subt_yy=0.2
      self.subtitle_k = 1
    else:
      self.subt_yy += -0.03
      self.subtitle_k += 1
      
    if type(subt) == type([]):
      for line in subt:
        print 'line: ',line
        tt.string = line
        tt.y = [self.subt_yy*self.page_aspect_ratio,]
        self.a.plot( tt )
        self.subt_yy += -0.03
    else:
      self.tt.string = subt
      self.tt.y = [self.subt_yy*self.page_aspect_ratio,]
      self.a.text( self.tt )

  def add_line( self, xc, yc, col="black",
                thick=1., last=1, init=0, component_name='map', dash=16 \
                ):

    self.line_init += 1

    x = cdms.createVariable(Numeric.array(xc))
    y = cdms.createVariable(Numeric.array(yc))

    y.setMissing( -999. )
    rl = 'rs_l%4.4i'   % self.line_init
    xv = 'line_x%4.4i' % self.line_init
    yv = 'line_y%4.4i' % self.line_init
    ## need to avoid overwriting earlier data
    ## example ncl code does this with  a delete, which presumably removes
    ## pointers -- that does not appear to work here.
   ## if self.min_value != None:
      ##ii = basic_utils.xx_where( lambda x: x > self.min_value, y )
      ##self.a[xv] = x[ii]
      ##self.a[yv] = y[ii]
    ##else:
    self.a[xv] = x
    self.a[yv] = y
    self.a( rl + ' = True ' )
    self.set_ncl( rl, 'gsLineThicknessF', thick)
    self.set_ncl( rl, 'gsLineColor', col)
    self.set_ncl( rl, 'gsLineDashPattern', dash)
    self.a('gsn_polyline(wks,%s,%s,%s,%s)'% (component_name,xv,yv,rl) )



  def ncl_annotate( self, plot, val, x, y ):
    print '>> ncl_annotate',val, x, y 
    self.a('gsn_text(wks,%s,"%s",%s,%s,anres)' % ( plot, val, x, y ) )

  def reset(self, clear=1):
    if clear == 1:
      if self.xvals_htag == 0:
        self.xvals = [0]

  def set_position( self, llx, lly, urx, ury ):
    if urx < llx:
      print 'upper right x (arg 3) should be > lower left x (arg 1)'
      print 'args = ',llx, lly, urx, ury
      raise 'error in set_position'
    if ury < lly:
      print 'upper right y (arg 4) should be > lower left y (arg 2)'
      print 'args = ',llx, lly, urx, ury
      raise 'error in set_position'

    self.bbllx = llx
    self.bblly = lly
    self.bburx = urx
    self.bbury = ury
    
  def x_data2norm( self, xx ):
    oo = []
    sc = (self.bburx-self.bbllx)/(self.xy.datawc_x2-self.xy.datawc_x1) \
            *self.page_aspect_ratio
    llx = self.bbllx*self.page_aspect_ratio
    for x in xx:
      oo.append( llx + sc*(x-self.xy.datawc_x1) )
    return oo

  def y_data2norm( self, yy ):
    oo = []
    sc = (self.bbury-self.bblly)/(self.xy.datawc_y2-self.xy.datawc_y1) \
            *self.page_aspect_ratio
    lly = self.bblly*self.page_aspect_ratio
    for y in yy:
      oo.append( lly + sc*(y-self.xy.datawc_y1) )
    return oo

  def set_xrange( self, xx, new=1 ):
    if type(xx) != type([]) or len(xx) < 2:
      self.data_xhi = None
      self.data_xlo = None
    elif new == 1:
      self.data_xhi = max(xx)
      self.data_xlo = min(xx)
    else:
      self.data_xhi = max( max(xx), self.data_xhi )
      self.data_xlo = min( min(xx), self.data_xlo )

  def set_x2( self, x0, lenx, step=1, ticks=[], subtic=0):
    self.xvals = map( lambda x: x*step + x0, range(lenx) )
    self.xvals_htag = 1

  def set_x( self, xx ):
    self.xvals = xx

##
## want to use following for cleaner overplotting.
## see ttt.py for comments.
##plot1('res@gsnFrame=False')
###########################
## new version, below, does not work. Example in ttt.py also
## shows that something more is needed to replot on same
## frame. 
###########################
  def create_plot( self ):

    if self.xvals_htag == 0:
      self.xvals = range(len(self.ydata))
      self.xvals_htag = 1

    x_axis = cdms.createAxis(Numeric.array( self.xvals) )
    x_axis.id = 'xax'
    if self.xaxis_name != None:
      x_axis.long_name = self.xaxis_name
    else:
      x_axis.long_name = '----'
    self.set_ncl('res', 'gsnFrame', False)
    self.set_ncl('res', 'gsnDraw', True)
    if  self.npl == 1:
      ydata = cdms.createVariable(Numeric.array(self.ydata),axes=[x_axis])
    else:
      ydata = cdms.createVariable(Numeric.array(self.ydata[0]),axes=[x_axis])
    ydata.setMissing( -999. )
    if self.yaxis_name != None:
      ydata.long_name = self.yaxis_name
    else:
      ydata.long_name = '----'

    self.a['y'] = ydata
#############################################
## position on page 
#############################################
    if self.bbury != None:
      self.set_ncl( 'res', 'vpHeightF', self.bbury - self.bblly )
      self.set_ncl( 'res', 'vpWidthF', self.bburx - self.bbllx )
      self.set_ncl( 'res', 'vpXF', self.bbllx )
      self.set_ncl( 'res', 'vpYF', self.bbury )
####
## line styles
    self.set_ncl( 'res', 'xyMonoDashPattern', 'True', raw=1 )
    self.set_ncl( 'res', 'xyLineThicknesses', self.line_thicknesses )
    self.set_ncl( 'res', 'xyDashPatterns', self.line_dash_pattern )
#############################################
# set colours, using list in self.colours
#
    cstr = '"' + string.join( ["white",] + self.p_colours, '","' ) + '"'
    
    self.a('gsn_define_colormap( wks,  (/' + cstr + '/) )' )\
#################################################
## set axis limits in data corrdinates
#################################################
    if self.data_xhi != None:
      self.set_ncl( 'res', 'trXMaxF', self.data_xhi )
      self.set_ncl( 'res', 'trXMinF', self.data_xlo )
    if self.data_yhi != None:
      self.set_ncl( 'res', 'trYMaxF', self.data_yhi )
      self.set_ncl( 'res', 'trYMinF', self.data_ylo )
############################################
# Change the default font.
    self.set_ncl( 'txres', 'txFont', 21 )
#        Set the font height.
    self.set_ncl( 'txres', 'txFontHeightF', 0.015 )
# justification of text
    self.set_ncl( 'txres', 'txJust', 'BottomLeft' )
    self.set_ncl( 'txres', 'txFontColor', 'black' )
## annotation font etc
    self.set_ncl( 'anres', 'txFont', self.anno_font_type )
#        Set the font height.
    self.set_ncl( 'anres', 'txFontHeightF', self.anno_font_height )
# justification of text
    self.set_ncl( 'anres', 'txJust', 'BottomLeft' )
    self.set_ncl( 'anres', 'txFontColor', 'black' )
#############################

    if self.subtitles != None:
      if type(self.subtitles) == type( {} ) and self.subtitles.get( 'block', 'void' ) == 'true':
        print 'working on this'
        for subt in self.subtitles['blocks']:
          self.set_subtitle( subt )
      else:
        self.set_subtitle( self.subtitles )

#############################################
## define plot
############################################
    if self.xdict.has_key(0):
       self.a['x'] = cdms.createVariable(Numeric.array(self.xdict[0]))
       self.a('plot=gsn_xy(wks,x,y,res)')
    else:
       self.a('plot=gsn_xy(wks,y&xax,y,res)')
############################################

    if self.npl == 1:
        self.add_line( self.xvals, self.ydata, component_name='plot' ) 
    else:
      for k in range(self.npl):
##
## trying to draw line over box, which currently is on top of previous lines
##
#
# now works in the sense of getting a line on the plot -- need to get control
## of colours.
###############
        if self.xdict.has_key(k):
          this_x = self.xdict[k]
        else:
          this_x = self.xvals
        print k, len(this_x), len( self.ydata[k] )
        self.add_line( this_x, self.ydata[k], col=self.p_colours[k], \
                       component_name='plot', \
                       thick=self.line_thicknesses[k], dash=self.line_dash_pattern[k] )
        if (k < len(self.plot_annotate)) and self.plot_annotate[k]:
          pa = self.plot_annotate[k]
          xx = pa.get( 'x',[1100,1200,1250] )
          yy = pa.get( 'y',[.55-k*0.05,.55-k*0.05] )
          tt = pa.get( 'a','Null' )
          self.add_line( xx[0:2], [yy[0],yy[0]], col=self.p_colours[k], \
                       component_name='plot', \
                       thick=self.line_thicknesses[k], dash=self.line_dash_pattern[k] )
          self.ncl_annotate( 'plot', tt, xx[2], yy[1] )
############################################
#  create image
############################################
    self.a('frame(wks)')
    self.a.nclrun()

  def to_file(self,fileroot=work_dir + 'example', type='eps'):
    valid_types = ['eps','ps','x11','pdf']
    self.a.plotname = fileroot 
    if type in valid_types:
      self.a.plotdev = type
      self.a.nclrun()
    else:
      print 'valid types are: ',valid_types
      print 'will probably fail'
      self.a.plotdev = type
      self.a.nclrun()
      

###########################################
### working version
  def oplot( self, yy, x=None, colour="black", just='l', \
              anno=None, \
              opts={}, count=1, line_width=-1, dash=0 ):
    if hasattr( yy, 'tolist' ):
      yy = yy.tolist()
    self.npl += 1
    self.p_colours.append( colour )

    if line_width==-1:
      line_width=self.line_thickness_def

    self.line_thicknesses.append( line_width )
    self.line_dash_pattern.append( dash )
    self.plot_annotate.append( anno )
#
#
    if x:
        self.xdict[self.npl-1] = x
    elif len(yy) == len(self.xvals):
      print 'adding new data with same length as existing axis'
      ln_x = self.xvals 
    elif len(yy) > len(self.xvals):
      if just == 'l':
        yy = yy[0:len(self.xvals)]
      else:
        yy = yy[-len(self.xvals):]
    else:
      ln_y = yy
      if just == 'l':
        for k in range(len(self.xvals)-len(yy)):
          yy.append( -999. )
      else:
        yyy = []
        for k in range(len(self.xvals)-len(yy)):
          yyy.append( -999. )
        yy = yyy + yy
         
    print 'oplot: self.npl=',self.npl
    if self.npl == 2:
        self.ydata = [self.ydata, yy ]
    else:
        self.ydata.append(yy)


  def add_poly( self, xc, yc, col="black", id=1, last=1, init=0, \
          coords='user', component_name='map', size=None):

    self.poly_init += 1
    rp = 'rs_p%4.4i' % self.poly_init
    self.a(rp+'=True')
    self.set_ncl( rp, 'gsEdgesOn',  True )       # draw border around polygons
    self.set_ncl( rp, 'gsEdgeColor', "black" )

    self.set_ncl( rp, 'gsFillColor', col )       # VA clim div 1

    if size != None:
      dx=size
    elif coords == 'ndc':
      dx = 0.01
    else:
      dx = 3

    if type(xc) == type([]):
      x = cdms.createVariable(Numeric.array(xc+[xc[0]]))
      y = cdms.createVariable(Numeric.array(yc+[yc[0]]))
      print 'y=',y
      print 'x=',x
    else:
      x = cdms.createVariable(Numeric.array([xc-dx,xc,xc+dx,xc,xc-dx]))
      y = cdms.createVariable(Numeric.array([yc,yc-dx,yc,yc+dx,yc]))

    xv = 'poly_x%4.4i' % self.poly_init
    yv = 'poly_y%4.4i' % self.poly_init
    ## need to avoid overwriting earlier data
    ## example ncl code does this with  a delete, which presumably removes
    ## pointers -- that does not appear to work here.
    self.a[xv] = x
    self.a[yv] = y
### component_name probably not needed here `dd`
    if coords == 'user':
      self.a('gsn_polygon (wks,%s,%s,%s,%s)' % ( component_name,xv,yv,rp) )
    else:
      self.a('gsn_polygon_ndc (wks,%s,%s,%s)' % ( xv,yv,rp) )
    ###self.a('delete(x)')## variable x does not exist

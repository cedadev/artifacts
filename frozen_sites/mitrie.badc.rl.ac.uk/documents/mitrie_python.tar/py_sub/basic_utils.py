#
###########################################################################
# module do_regress.py
#
###########################################################################
#
# Utilities for proxy based temperature reconstructions
###########################################################################
from Numeric import *
import string, shelve
from config import plot_dir, data_dir, work_dir

def yy_where( cond, data, bb ):
   return compress( map( cond, data), bb )

def xx_where( cond, data, extract=False, dimension=-1 ):
   if extract:
     if type( data[0] ) == type( ' ' ):
       return map( lambda x: string.strip(string.join(x, '')), compress ( map( cond, data), data, dimension=0 ) )
     else:
       return compress( map( cond, data), data, dimension=dimension )
   else:
     return compress( map( cond, data), range(len(data)), dimension=dimension )

def abs_cmp(x,y):
   if abs(x)==abs(y):
     return 0
   if abs(x) > abs(y):
     return 1
   return -1

def where( cond, data ):
   return compress( map( cond, data), range(len(data)) )

def smooth( aa, nn, pad=False, missing=None, to_ends=False, and_max=False):
  if nn == 1:
    return aa

  ll = len(aa)
  if ll < nn:
    raise 'ut.smooth: called with array too short for nn=',nn
  oo = []
  rn = 1./float(nn)
  for i in range(ll-nn+1):
    if missing == None:
      oo.append( sum( aa[i:i+nn] )*rn )
    else:
      os = 0.
      nnn = 0
      for a in aa[i:i+nn]:
        if a != missing: 
          os +=a 
          nnn+=1
      if nnn > 0:
        os = os/float(nnn)
      else:
        os = missing
      oo.append( os )

  if and_max:
    om = []
    for i in range(ll-nn+1):
      om.append( max( aa[i:i+nn] ) )


  if pad:
    pp = []
    for i in range( (nn-1)/2 ):
      pp.append( oo[0] )
    for i in range( nn-1 - (nn-1)/2 ):
      oo.append( oo[-1] )
    oo = pp + oo
  elif to_ends:
    pp = []
    for i in range( (nn-1)/2 ):
      pp.append( sum( aa[0:i+1] )/float(i+1) )
    for i in range( ll - (nn-1 - (nn-1)/2), ll ):
      oo.append( sum( aa[i:ll] )/float(ll-i) ) 
    oo = pp + oo
    if len(oo) != ll:
      print 'failed in smooth::',len(oo),ll
      raise 'fatal'

  if and_max:
    return (oo,om)
  else:
    return oo


##############################################
## return list of differences > dmin, from 
## points listed in nog. nog is a list of
## tuples, each (i,j): (longitude,latitude)
##############################################
def diff_1( a,b, nog, dmin ):

  oo = []
  for k in range(len(nog)):
    tup = nog[k]
    dd = a[tup[1],tup[0]] - b[tup[1],tup[0]]
    if abs(dd) > dmin:
      oo.append( (k,dd,tup) )
  if len(oo) == 0:
    print 'no differences outside range found'
  else:
    print len(oo), ' differences outside range'
  return oo


def choose(a,b,flag):
  if flag:
    return a
  else:
    return b

def xmean( aa, tt, range, missing=None):
  ii = xx_where( lambda x: (x >= range[0]) and (x <= range[1] ), tt )
  if len(ii) < 2:
    print 'not enough data in speciified range: ',range
    raise 'error in xmean'

  ss = 0
  nn = 0
  for i in ii:
    if aa[i] != missing:
      ss+= aa[i]
      nn +=1
  if nn != 0:
    ss = ss/nn
  else:
    ss = missing

  return map( lambda x:choose(x-ss,x,x != missing),aa)

def eq_val( a, b, verbose=0 ):
   if len(a) != len(b):
     if verbose >= 1:
       print 'eq_val: objects have different lengths: ', len(a), len(b)
     return False

   for k in range(len(a)):
     if a[k] != b[k]:
       if verbose >= 1:
         print 'eq_val: objects differ at %i: %s, %s' % (k, a[k], b[k] )
       return False

   if verbose >= 2:
     print 'eq_val: objects are equal'
   return True

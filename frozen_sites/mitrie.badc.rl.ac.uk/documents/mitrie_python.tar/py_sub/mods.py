import Numeric


def detrend_2d( aa, dim=1 ):
    oo = []
    print aa[0,0]
    if dim == 1:
      l = len( aa[0] )
      print 'detrending on length ',l
      ww = 1./float(l)
      xx = map( lambda x:x-0.5*float(l-1), range(l) )
      rxx = 1./Numeric.dot( xx,xx )
      for a in aa:
        at = Numeric.dot(xx,a)*rxx
        a = map( lambda x,y: x - at*y,  a, xx )
        oo.append(a)
    else:
      l = len( aa )
      ww = 1./float(l)
      xx = map( lambda x:x-0.5*float(l-1), range(l) )
      rxx = 1./Numeric.dot( xx,xx )
      raise 'mods.detrend_2d:: can not do detrend on second dimension yet'
    return oo

################################
def detrend_1d( aa ):
    l = len( aa )
    ww = 1./float(l)
    xx = map( lambda x:x-0.5*float(l-1), range(l) )
    rxx = 1./Numeric.dot( xx,xx )
    at = Numeric.dot(xx,aa)*rxx
    a = map( lambda x,y: x - at*y,  aa, xx )
    return a


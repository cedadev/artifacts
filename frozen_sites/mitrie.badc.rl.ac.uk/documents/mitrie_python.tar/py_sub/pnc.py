import shelve, cdms, string
import plot_ma, basic_utils
from Numeric import *
from config import work_dir, data_dir, plot_dir

fpat = 'mr_%(proxy_set_id)s_%(start)s_%(regression_type)s_%(calibration_field)s' + \
       '_%(version)2.2i.%(proxy_option_code)2.2i.%(calibration_option_code)3.3i'

odir = work_dir + 'shelves/new/'

files = { 'col':data_dir + 'nc/mitrie_new_reconstructions_v01.nc', \
          'col1400':data_dir + 'nc/mitrie_new_reconstructions_1400_v01.nc', \
          'inst':data_dir + 'nc/mitrie_instrumental_v01.nc', \
          'cited':data_dir + 'nc/mitrie_cited_reconstructions_v01.nc',
          'ppc_col':data_dir + 'nc/mitrie_new_proxy_pcs_1000_v01,nc',
          'ppc_col1400':data_dir + 'nc/mitrie_new_proxy_pcs_1400_v01,nc'
         }

def get_ts_set( start, ny, defs ):
  nn = 0
  for d in defs:
    nn += len( d[1] )

  aa = multiarray.zeros( (nn,ny), 'f' )
  aa[:,:] = -999.
  nn = 0
  nnf = 0
  for d in defs:
    print files[d[0]]
    nc = cdms.open( files[d[0]], 'r' )
    time = nc.getAxis('time').getValue()
    d0, d9 = map( int, (time[0],time[-1]) )
    for tag in d[1]:
      print tag
      if tag in nc.variables.keys():
        vv = nc.variables[tag].getValue().tolist()
        if d0 >= start:
          if d9 == start + ny -1:
            aa[nn,d0-start:] = vv[:]
          elif d9 > start + ny -1:
            aa[nn,d0-start:] = vv[:ny]
          else:
            aa[nn,d0-start:d9-d0+1] = vv[:]
        else:
          if d9 == start + ny -1:
            aa[nn,:] = vv[start-d0:]
          elif d9 > start + ny -1:
            aa[nn,:] = vv[start-d0:start-d0+ny]
          else:
            print aa.shape,'::',len(vv)
            print d9-d0+1, start-d0
            print d0,d9,start,ny

            aa[nn,:d9-start+1] = vv[start-d0:]
        
        if tag in ['huang_etal1998','esper_etal2002']:
          print '>>>>',tag
          aa[nn,:] = pp_lit_recon( aa[nn,:], tag, range(start,start+ny) )

        nn+=1
      else:
        print tag,' not found in ',d[0],files[d[0]]
        print nc.variables.keys()
        nnf +=1
    nc.close()
  if nnf != 0:
      raise 'errors detected'
  return aa
      
  
def pp_lit_recon( vv, proxy_set_id, time):
    if proxy_set_id == 'huang_etal1998':
      print '==========filling huang et al'
      ii = basic_utils.xx_where( lambda x: x != -999., vv )
      for i in range( len(ii) -1 ):
        incr = (vv[ii[i+1]] - vv[ii[i]])/(time[ii[i+1]] - time[ii[i]])
        for j in range( ii[i]+1, ii[i+1] ):
          vv[j] = vv[ii[i]] + (j-ii[i])*incr
    elif proxy_set_id == 'esper_etal2002':
      ii = basic_utils.xx_where( lambda x: x > -990., vv[:] )
      print 'scaling esper_etal2002', len(ii)
      for i in ii:
        vv[i] = vv[i]*1.73
    return vv


ptt = 4
def p(ptt,opt=None):
  pat = 'mr_%(proxy_set_id)s_%(start)s_%(regression_type)s_%(calibration_field)s' + \
       '_%(version)2.2i.%(proxy_option_code)2.2i.%(calibration_option_code)3.3i'

  proxy_option_code = 2
  start = 1000
  regression_type = 'invr'
  regression_type = 'cvm'
  calibration_field = 'nht'
  calibration_option_code = 1
  version = 1
  std_period = 'cal'
  if proxy_option_code == 2:
    std_period = 'full'

  if ptt in ['f1','f1b','x2a','x2b']:
  
     idlist = ['jones_etal1998','mann_etal1999', \
            'huang_etal1998', 'crowley_lowery2000', \
            'briffa_etal2001','esper_etal2002', \
            'mann_jones2003', 'moberg_etal2005', \
            'oerlemans2005', 'hegerl_etal2006']

     if ptt in ['f1','x2a','x2b']:
       plist = ['JBB1998','MBH1999','HPS2000','CL2000',\
           'BOS2001','ECS2002','MJ2003','MSH2005',\
           'OER2005','HCA2006','NH Temp.']
       anno_font_height=None
       dxfrac = None
     else:
       plist = ['Jones et al., 1998', 'Mann et al., 1999', 'Huang et al., 2000',
                'Crowley and Lowery, 2000', 'Esper et al., 2002', \
                'Briffa et al., 2001', \
                'Mann and Jones, 2003', 'Moberg et al., 2005', 'Oerlemans, 2005', \
                'Hegerl et al., 2006', 'Jones et al., 1986']
       anno_font_height=0.013
       dxfrac = 0.07
     cols=['red','black','blue','brown','green',\
                       'purple','orange','grey','black',\
                        'blue','red']
     dashp = [0, 0,16,0,0,0,0,0,16,0,16,16,16]

     if ptt == 'x2a':
       kp=0
       for k in range(4):
         plist.pop(kp)
         cols.pop(kp)
         dashp.pop(kp)
         idlist.pop(kp)
     if ptt == 'x2b':
       kp=4
       for k in range(4):
         plist.pop(kp)
         cols.pop(kp)
         dashp.pop(kp)
         idlist.pop(kp)

     if opt == 'short':
       start=1850
       ksmh=0
     else:
       start=1000
       ksmh=10
     defs = [ ('cited',idlist),('inst',['nh']) ]

     bb = get_ts_set( 1000, 1006, defs )

     plot_file = plot_dir + 'mitrie_%s' % ptt
     if opt == 'short':
       plot_file += '_s'
     plot_ma.run( bb, range(1000,2006), plist, start=start, \
                 cols=cols, dashp=dashp, \
                 yrange = [-0.8,0.8], \
                 anno_font_height=anno_font_height,
                 dxfrac = dxfrac,
                 plot_file = plot_file, \
                 end_year=2006, ksmh = ksmh )
     return (plot_file, bb )

  elif ptt in ['f4','f5']:

     if ptt in ['f4']:
        regression_type = 'cvm'
     else:
        regression_type = 'invr'

     idlist = ['jbb','mbh', 'ecs', 'msh', 'hca', 'union']

     tags = []
     for proxy_set_id in idlist:
       id = fpat % locals()
       tags.append( id )

     defs = [ ('col',tags),('cited',['mann_etal1999','huang_etal1998']),('inst',['nh']) ]

     bb = get_ts_set( 1000, 1006, defs )
     nn=9

     plist = ['JBB','MBH',\
           'ECS','MSH',\
           'HCA','Union','MBH1999','HPS2000','NH Temp.']
     anno_font_height=None
     dxfrac = None

     if regression_type == 'cvm':
       extras = [ {'x':[1071,1111,1091,1091,1091],'y':[0.25,0.25,0.25,0.30,0.20], 'col':'cyan','dash':0 },
               {'x':[1964,2004,1984,1984,1984],'y':[0.84,0.84,0.84,0.89,0.79], 'col':'red','dash':0 } ]
     else:
       extras = None

     plot_file = plot_dir + 'mitrie_%s' % ptt
     plot_ma.run( bb[:nn,:], range(1000,2006), plist[:nn], start=1000, \
                 cols=['red','green','purple','grey','blue',\
                       'cyan','black','blue','red',\
                        'blue','orange'], \
                 yrange = [-0.8,0.9], \
                 extras = extras, \
                 anno_font_height=anno_font_height,
                 dxfrac = dxfrac,
                 plot_file = plot_file, \
                 dashp = [0, 0,0,0,0,0,16,16,16,16,16,16], \
                 end_year=2006, ksmh = 10 )

     return (plot_file, bb )

  elif ptt == 'f3':

    npl=8
    proxy_option_code = 2
    regression_type = 'invr'
    proxy_set_id = 'mbh'
    id = fpat % locals()
    tags = []
    for bit in ['_ff','','_pc']:
      tags.append( id + bit )
    proxy_set_id = 'mbhx'
    id = fpat % locals()
    tags.append( id + '_std' )

    regression_type = 'cvm'
    opt = 'mbh'
    proxy_set_id = 'mbh'
    id = fpat % locals()
    tags.append( id   )
  
    plist = []
    for k in range(5):
      plist.append( '(%s)' % (k+1) )
    plist += ['MBH1999','HPS2000','NH Temp']

    defs = [ ('col',tags),
             ('cited',['mann_etal1999','huang_etal1998']),
             ('inst',['nh']) ]
    bb = get_ts_set( 1000, 1006, defs )
    nn=npl
    plot_file = plot_dir + 'mitrie_%s' % (ptt) 
    plot_ma.run( bb[:nn,:], range(1000,2006), plist[:nn], start=1000, \
                 cols=['orange','cyan','purple','yellow','green',\
                       'black','blue','red',\
                        'blue','orange'], \
                 yrange = [-0.8,0.8], \
                 plot_order = [5,0,1,2,3,4,6,7,8,9,10,11],\
                 plot_file = plot_file, \
                 dashp = [0,16,0,16,0,0,16,16, 16,16,16,16], \
                 end_year=2006, ksmh = 10 )
    return (plot_file, bb )

  elif ptt in  ['f7','f7b']:
  
     proxy_set_id = 'union'
     fname = fpat % locals()
     defs = [ ('inst',['nh']), ('col',[fname]) ]
     bb = get_ts_set( 1000, 1006, defs )
     ymx = .212
     yp2 = .212 + 0.3
     extras = [ {'x':[1850,2006],'y':[yp2,yp2], 'col':'grey','dash':16, 'seq':0 }, \
                {'x':[1850,2006],'y':[ymx,ymx], 'col':'grey','dash':0, 'seq':0 } ]

     if ptt == 'f7b':
       plist = ['NH Temperature','Reconstruction']
     else:
       plist = ['NH Temperature','Union']
     plot_file = plot_dir + 'mitrie_%s' % ptt
     plot_ma.run( bb, range(1000,2006), plist, start=1850, \
                 cols=['red','cyan'], \
                 dashp = [0, 0], \
                 extras = extras, 
                 plot_file = plot_file, \
                 end_year=2006, ksmh = 0 )

     return (plot_file, bb )

  elif ptt == 'f6':

     ii = shelve.open( '/data2/mjuckes/mitrie/work/shelves/recon_pp_10','r' )
     idlist = ['jones_etal1998', 'mann_etal1999', 'esper_etal2002', 'moberg_etal2005', 'hegerl_etal2006', 'union']
     ngr = len(idlist) + 1
     aa = multiarray.zeros( (ngr,201), 'f' )
     aa[:,:] = -999.
  
     k=0
     for id in idlist:
       aa[k,:] = ii['lcdtr'][k][:201]
       k+=1
     aa[k,:] = ii['lcdtr'][-1][:201]

     plist = ['JBB','MBH', 'ECS','MSH', 'HCA','Union','NH Temp.']
     plot_file = plot_dir + 'mitrie_%s' % ptt
     plot_ma.run( aa, range(00,201), plist, start=00, \
                 cols=['brown', 'black','purple','grey','blue','cyan','red','green','black'], \
                 dashp = [0, 0,0,0,0,0,16,16,0,16], \
                 rmmean = None, \
                 plot_file = plot_file, \
                 end_year=200, ksmh = 0 )

     return (plot_file, aa )

  elif ptt in ['s1','s2']:

      kmo=1
      if ptt == 's1':
        pad_opt = 0
      else:
        pad_opt=1

      if pad_opt == 1:
        slist = [-1,-1,-1,-1,1]
      else:
        slist = [-1,-1,1,1,1]

      ny=581
      start=1400
      olist = ['mbh','mbhx','std','cen']
      plist = ['(1) As MBH1998','(2) MBHX', '(3) STD','(4) CEN','(5) Archived']
      nc = cdms.open( data_dir + 'nc/mitrie_new_proxy_pcs_%4.4i_v01.nc' % start, 'r' )

      aa = multiarray.zeros( (5,ny), 'f' )
      aa[:,:] = -999.
      k=0
      for opt in olist:
        nid = 'mppc%2.2i_%s_%4.4i_%s_%2.2i' % ( kmo, 'itrdb_namer', start, opt, pad_opt )
        aa[k,:] = nc.variables[nid].getValue()
        k+=1
      nc.close()

      nc = cdms.open( data_dir + 'nc/mann_etal1998_x.nc', 'r' )
      tag = 'NorthAmericaITRDB_pc%2.2i' % kmo
      print nc.variables[tag].getattribute('long_name')
      i0 = start - nc.getAxis('time').getValue()[0]
      aa[k,:] = nc.variables[tag].getValue().tolist()[i0:i0+ny]
      nc.close()

      for k in range(5):
        for i in range(ny):
          aa[k,i] = slist[k]*aa[k,i]

      for k in range(5):
        ss = sqrt( sum( aa[k,:]**2 )/float(ny) )
        print ss
        for i in range(ny):
          aa[k,i] = aa[k,i]/ss

      nn=5
      plot_file = plot_dir + 'mitrie_%s_%2.2i' % (ptt,kmo)
      plot_ma.run( aa[:nn,:], range(start,1981), plist[:nn], start=start, \
                 cols=['red','black','blue','grey','green',\
                       'purple','yellow','grey','yellow',\
                        'blue','orange'], \
                 yrange = [-03.0,02.0], \
                 yaxis_name = 'PC [normalised]', 
                 plot_file = plot_file, \
                 dashp = [0, 16,0,0,16,0,0,16,0,16,16,16], \
                 end_year=2006, ksmh = 10 )

      return (plot_file, aa )

  elif ptt in ['s3', 's4']:

    npl=8
    start = 1400
    proxy_option_code = 2
    regression_type = 'invr'
    if ptt == 's4':
      opt = 2
      calibration_option_code = 2
    else:
      opt=1
      calibration_option_code = 1
    proxy_set_id = 'mbh98'
    id = fpat % locals()
    tags = [id]
    proxy_set_id = 'mbh98x'
    id = fpat % locals()
    tags.append( id + '_std' )
    tags.append( id + '_cen' )

    proxy_option_code = 12
    id = fpat % locals()
    tags.append( id + '_std' )

    proxy_option_code = 2

    regression_type = 'cvm'
    opt = 'mbh'
    proxy_set_id = 'mbh98'
    id = fpat % locals()
    tags.append( id   )
  
    plist = ['(1) As MBH1998', '(2) std','(3) cen','(4) std, padded','(5) cvm', \
             '(6) MBH1999','(7) HPS2000','(8) NH Temp']

    defs = [ ('col1400',tags),
             ('cited',['mann_etal1999','huang_etal1998']),
             ('inst',['nh']) ]
    bb = get_ts_set( 1400, 606, defs )
    nn=npl
    plot_file = plot_dir + 'mitrie_%s_%s' % (ptt,calibration_option_code) 
    plot_ma.run( bb[:nn,:], range(1400,2006), plist[:nn], start=1400, \
                 cols=['orange','cyan','red','purple','yellow','green',\
                       'grey','blue','red',\
                        'blue','orange'], \
                 yrange = [-0.8,0.8], \
                 plot_order = [5,0,1,2,3,4,6,7,8,9,10,11],\
                 plot_file = plot_file, \
                 dashp = [0,16,16,16,16,0,16,16,16, 16,16,16,16], \
                 end_year=2006, ksmh = 10 )
    
    return (plot_file, bb )

  elif ptt == 's5':

      kmo=1
      ny=981
      start=1000
      olist = ['mbh','mbhx','std','cen']
      slist = [-1,-1,-1,-1,-1,1]
      plist = ['(1) As MBH1999','(2) MBHX', '(3) STD','(4) CEN ','(5) Archived','(6) Other arch.']
      nc = cdms.open( data_dir + 'nc/mitrie_new_proxy_pcs_%4.4i_v01.nc' % start, 'r' )

      aa = multiarray.zeros( (6,ny), 'f' )
      aa[:,:] = -999.
      k=0
      pad_opt = 0
      for opt in olist:
        nid = 'mppc%2.2i_%s_%4.4i_%s_%2.2i' % ( kmo, 'itrdb_namer', start, opt, pad_opt )
        aa[k,:] = nc.variables[nid].getValue()
        k+=1
      nc.close()

      nc = cdms.open( data_dir + 'nc/mitrie_proxies_v01.nc', 'r' )
      i0 = start - nc.getAxis('time').getValue()[0]
      print nc.variables['mbh99_01'].getattribute('long_name')
      aa[k,:] = nc.variables['mbh99_13'].getValue().tolist()[i0:i0+981]
      k+=1
      aa[k,:] = nc.variables['mbh99_%2.2i' % kmo].getValue().tolist()[i0:i0+981]
      nc.close()

      scale_by = 'list'
      if scale_by == 'corr':
        for k in range(4):
          ss = sum( aa[4,:]*aa[k,:] )
          if ss < 0:
            aa[k,:] = - aa[k,:]
      else:
        for k in range(6):
          for i in range(ny):
            aa[k,i] = slist[k]*aa[k,i]

      for k in range(6):
        ss = sqrt( sum( aa[k,:]**2 )/float(ny) )
        print ss
        for i in range(ny):
          aa[k,i] = aa[k,i]/ss

      nn=6
      plot_file = plot_dir + 'mitrie_%s_%2.2i' % (ptt,kmo) 
      plot_ma.run( aa[:nn,:], range(start,1981), plist[:nn], start=start, \
                 cols=['red','black','blue','grey','green',\
                       'yellow','yellow','grey','yellow',\
                        'blue','orange'], \
                 yrange = [-03.0,02.0], \
                 yaxis_name = 'PC [normalised]', 
                 plot_file = plot_file, \
                 dashp = [0, 16,0,0,16,16,0,16,0,16,16,16], \
                 end_year=2006, ksmh = 10 )

      return (plot_file, aa )
  elif ptt in ['s6','s7']:

     regression_type = 'cvm'
     idlist = ['union','u85','u85b']

     if ptt == 's7':
       plot_start=1850
       plist = [ 'Union','U85','U85b','NH Temp.']
       plot_order = [3,0,1,2,3,4,6,7,8,9,10,11]
       ksmh=0
     else:
       opt=0
       plot_start=1000
       plist = [ 'Union','U85','U85b','NH Temp.']
       plot_order = [3,0,1,2,3,4,6,7,8,9,10,11]
       ksmh=10

     tags = []
     for proxy_set_id in idlist:
       id = fpat % locals()
       tags.append( id )

     if opt == 1:
       defs = [ ('col',tags),('inst',['nh']) ]
     else:
       defs = [ ('col',tags),('cited',['mann_etal1999','huang_etal1998']),('inst',['nh']) ]
       defs = [ ('col',tags),('inst',['nh']) ]

     bb = get_ts_set( 1000, 1006, defs )

     anno_font_height=None
     dxfrac = None

     plot_file = plot_dir + 'mitrie_%s' % ptt 
     plot_ma.run( bb, range(1000,2006), plist, start=plot_start, \
                 cols=['red','green','purple','grey','blue',\
                       'cyan','black','blue','red',\
                        'blue','orange'], \
                 yrange = [-0.8,0.9], \
                 anno_font_height=anno_font_height,
                 dxfrac = dxfrac,
                 plot_order=plot_order,
                 plot_file = plot_file, \
                 dashp = [0, 0,16,0,0,0,16,16,16,16,16,16], \
                 end_year=2006, ksmh = ksmh )
     return (plot_file, bb )
  elif ptt in ['s8']:

     if ptt in ['s8']:
        regression_type = 'cvm'
     else:
        regression_type = 'invr'

     idlist = []
     plist = []
     for o in range(18):
       idlist.append( 'um%2.2i' % (o+1) )
       plist.append( 'um%2.2i' % (o+1) )

     tags = []
     for proxy_set_id in idlist:
       id = fpat % locals()
       tags.append( id )
       
     defs = [ ('col',tags) ]

     bb = get_ts_set( 1000, 1006, defs )

     anno_font_height=None
     dxfrac = None

     plot_file = plot_dir + 'mitrie_%s' % ptt 
     plot_ma.run( bb, range(1000,2006), plist, start=1000, \
                 cols=['red','green','purple','grey','blue',\
                       'cyan','yellow','orange','black',\
                       'red','green','purple','grey','blue',\
                       'cyan','yellow','orange','black' ], \
                 yrange = [-0.8,0.9], \
                 anno_font_height=anno_font_height,
                 dxfrac = dxfrac,
                 plot_file = plot_file, \
                 dashp = [0, 0,0,0,0,0,0,0,0,16,16,16,16,16,16,16,16,16], \
                 end_year=2006, ksmh = 10 )
     return (plot_file, bb )

  elif ptt == 's9':

      kmo=1
      if opt in [1,2]:
        pad_opt = opt
      else:
        pad_opt=0

      if pad_opt == 1:
        slist = [1,1,1,1,-1]
      else:
        slist = [-1,-1,-1,-1,1]

      ny=581
      start=1400
      olist = ['mbh','mbhx','std','cen']
      plist = ['(1) As MBH1998','(2)', '(3)','(4)','(5) Archived']

      nc = cdms.open( data_dir + 'nc/mitrie_new_proxy_pcs_1400_v01.nc', 'r' )
      aa = multiarray.zeros( (5,ny), 'f' )
      aa[:,:] = -999.
      k=0
      for opt in olist:
        nid = 'mppc%2.2i_%s_%4.4i_%s_%2.2i' % ( kmo, 'stahle_swm', start, opt, pad_opt )
        aa[k,:] = nc.variables[nid].getValue()
        k+=1
      nc.close()

      nc = cdms.open( data_dir + 'nc/mann_etal1998_x.nc', 'r' )
      tag = 'StahleSouthwest_pc%2.2i' % kmo
      print nc.variables[tag].getattribute('long_name')
      i0 = start - nc.getAxis('time').getValue()[0]
      aa[k,:] = nc.variables[tag].getValue().tolist()[i0:i0+ny]
      nc.close()

      for k in range(5):
        for i in range(ny):
          aa[k,i] = slist[k]*aa[k,i]

      for k in range(5):
        ss = sqrt( sum( aa[k,:]**2 )/float(ny) )
        print ss
        for i in range(ny):
          aa[k,i] = aa[k,i]/ss

      nn=5
      plot_file = plot_dir + 'mitrie_%s_%2.2i_%2.2i' % (ptt,kmo,pad_opt) 
      plot_ma.run( aa[:nn,:], range(start,1981), plist[:nn], start=start, \
                 cols=['red','black','blue','brown','green',\
                       'purple','yellow','grey','yellow',\
                        'blue','orange'], \
                 yrange = [-01.0,01.0], \
                 yaxis_name = 'PC [normalised]', 
                 plot_file = plot_file, \
                 dashp = [0, 16,0,0,16,0,0,16,0,16,16,16], \
                 end_year=2006, ksmh = 10 )
      return (plot_file, aa )

  elif ptt == 'x2':
      slist = [-1,-1,-1,-1]

      ny=581
      start=1400
      olist = ['mbh','mbhx']
      plist = ['(1) As MBH1998','(2) MBHX', '(3) ','(4) ']
      nc = cdms.open( data_dir + 'nc/mitrie_new_proxy_pcs_%4.4i_v01.nc' % start, 'r' )

      kmo=1
      nn=4
      aa = multiarray.zeros( (nn,ny), 'f' )
      aa[:,:] = -999.
      k=0
      for pad_opt in [0,1]:
        for opt in olist:
          nid = 'mppc%2.2i_%s_%4.4i_%s_%2.2i' % ( kmo, 'itrdb_namer', start, opt, pad_opt )
          aa[k,:] = nc.variables[nid].getValue()
          pl = nc.variables[nid].proxy_list
          bits = string.split( pl, '; ')
          bits.sort()
          print len(bits), string.join(bits[0:10], '; ' )
          print aa[k,0:6]
          k+=1
      nc.close()

      for k in range(nn):
        for i in range(ny):
          aa[k,i] = slist[k]*aa[k,i]

      for k in range(nn):
        ss = sqrt( sum( aa[k,:]**2 )/float(ny) )
        print ss
        for i in range(ny):
          aa[k,i] = aa[k,i]/ss

      plot_file = plot_dir + 'mitrie_%s_%2.2i' % (ptt,1) 
      plot_ma.run( aa, range(start,1981), plist, start=start, \
                 cols=['red','black','blue','brown','green',\
                       'purple','yellow','grey','yellow',\
                        'blue','orange'], \
                 yrange = [-03.0,02.0], \
                 yaxis_name = 'PC [normalised]', 
                 plot_file = plot_file, \
                 dashp = [0, 0,16,16,16,0,16,0,16,16,16], \
                 end_year=2006, ksmh = 10 )
      return (plot_file, aa )
  else:

     print 'no action'
     aa = None
  return aa

def all():
  fl=[]
  for o in ['f1','f3','f4','f5','f6','f7','s1','s2','s3','s4','s5','s6','s7']:
    file, aa = p(o)
    fl.append( file )
  for f in fl:
    print f
  return fl


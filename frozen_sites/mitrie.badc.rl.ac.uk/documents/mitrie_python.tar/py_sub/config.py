work_dir = '/data2/mjuckes/mitrie_v1/work/'
plot_dir = '/data2/mjuckes/mitrie_v1/work/plots/'
data_dir = '/data2/mjuckes/mitrie_v1/data/'

union_klist = ['mcslo_002', 'mcslo_004', 'mcslo_009', 'mcslo_010', 'mcslo_011', \
                  'mcshi_001', 'mcshi_002', 'mcshi_005', \
                  'ecs_002', 'ecs_009', 'ecs_011', 'ecs_012', \
                  'jbb_001', 'jbb_002', 'jbb_010', \
                  'mbh99_08', 'mbh99_11', 'mbh99_12']


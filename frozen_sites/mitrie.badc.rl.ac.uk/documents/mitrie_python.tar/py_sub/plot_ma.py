import pr, cdms, string, datetime, basic_utils
#
# copied from p_d.py.
# produces cols, meth sets of plots for review
#
from Numeric import *
from config import * 

full_info=-1

def get_positions( nn, xoffset, ystart, xrange=xrange, ncol=None, line_len=100, dy=0.08, dytxt=0.025 ):
  if ncol == None:
    if nn <= 3:
      ncol=1
    else:
      ncol=2
  
  npc = (nn-1)/ncol + 1
  oo = []
  xx = [0,line_len,line_len*1.3]

  x0 = xrange[0] + xoffset
  if ncol==2:
    xtst = (xrange[0]+xrange[1])*0.5

  for i in range(npc):
    yy = ystart - i*dy 
    oo.append( [ map(lambda x: x+x0, xx), [yy,yy-dytxt] ] )

  if ncol == 1:
    return oo

  for i in range(npc,nn):
    yy = ystart - (i-npc)*dy 
    oo.append( [ map(lambda x: x+xtst, xx), [yy,yy-dytxt] ] )

  return oo
  

## cols:: reconstructions from different proxy collections.
## meth:: reconstructions with different standardisations.

cols_def = ['black','green','blue','red','orange','cyan','black', \
        'magenta','red','cyan','blue','red', 'orange','cyan', \
        'magenta','red','cyan','blue','red', 'orange','cyan']

class sorter:

  def __init__( self, lamb ):
    self.lamb = lamb

  def cmp(self,x,y):
    return cmp( self.lamb(x), self.lamb(y) )


def run( aa, time, 
         plist,
         start = 1000, end_year=1980,
         xax_offset = 0,
         ksmh = 10,
         cols = None,
         dashp = None,
         yrange = None,
         pidlist=False,
         anno_font_height=0.015,
         dxfrac = 0.10,
         dyp = 0.050,
         oplist =[], 
         extras = None, 
         yaxis_name = 'Temperature Anomaly [K]',
         plot_order = None,
         plot_upper = False,
         plot_file = 'test',
         rmmean=[1866,1970] ):

  if anno_font_height == None:
         anno_font_height=0.015
  if dxfrac == None:
         dxfrac = 0.10
  if cols == None:
    cols = cols_def
  if dashp == None:
    dashp = [0,0,0,0,16,0,0,16,16,16,16,16,16,16,0,0,0,0]
    
  if ksmh > 0:
      time_1 = basic_utils.smooth( time, 2*ksmh+1, missing=-999. )
  else:
      time_1 = time

  p = pr.plot( )
  xll = .20
  yll = .40
  xur = .85
  yur = .90
  p.set_position( xll, yll, xur, yur )
  
########################################################
  ny = len(time_1)
  print 'ny=',ny
  end = start+ksmh + ny-1
  xrange = [start+xax_offset,end_year]
  p.set_x2( start+ksmh, ny, ticks=100, subtic=20 )

  p.set_xrange( xrange )

  dl = []
  for k in range(len(plist)):
    d = aa[k]
    if rmmean != None:
      d1 = basic_utils.xmean( d, time, rmmean, missing=-999. )
    else:
      d1 = d

    if ksmh > 0:
      d1 = basic_utils.smooth( d1, 2*ksmh+1, missing=-999. )
 
    dl.append( d1 )

  if yrange == None:
    yrange = [-1.,1.]
  
  ddxx = (end_year-start)*dxfrac
  dy = 0.05*( yrange[1]-yrange[0] )
  dytxt = .4*dy
  psts = get_positions( len(dl), ddxx, 0.95*yrange[1]+0.05*yrange[0], \
          xrange=[start,end_year],\
          line_len=ddxx, dy=dy, dytxt=dytxt )
  p.plot( dl[0], x=time_1, yrange=yrange, line_width=3, \
             anno_font_height = anno_font_height, \
             yaxis_name=yaxis_name, \
             anno = { 'x':psts[0][0], 'y':psts[0][1], 'a':plist[0] } )

  if extras != None:
    for k in range( len(extras) ):
      if extras[k].get( 'seq', 1 ) == 0:
        p.oplot( extras[k]['y'], x=extras[k]['x'], colour=extras[k]['col'], dash=extras[k]['dash'] )

  for kk in range( 0, len(dl) ):
    if plot_order == None:
      k = kk
    else:
      k = plot_order[kk]
    p.oplot( dl[k], x=time_1, colour=cols[k], dash=dashp[k], \
             anno = { 'x':psts[k][0], 'y':psts[k][1], 'a':plist[k] } )
  
  if extras != None:
    for k in range( len(extras) ):
      if extras[k].get( 'seq', 1 ) == 1:
        p.oplot( extras[k]['y'], x=extras[k]['x'], colour=extras[k]['col'], dash=extras[k]['dash'] )

  p.create_plot()
  #
  print 'attempting output to ',plot_file
  all_ptypes = ['eps','pdf','ps']
  for ptype in ['eps']:
    p.to_file( fileroot=plot_file, type=ptype)



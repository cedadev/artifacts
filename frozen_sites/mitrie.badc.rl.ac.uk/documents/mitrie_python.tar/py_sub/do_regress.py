#
###########################################################################
# module do_regress.py
#
###########################################################################
#
# Utilities for proxy based temperature reconstructions
###########################################################################
from Numeric import *
import cdms
import string, shelve, mods
from config import data_dir, work_dir
import basic_utils

class regresser:

  def __init__(self, ncfile=data_dir+'nc/mitrie_proxies_v01.nc',
            xrange=(1000,1980), 
            std_opt='std',
            key_list=None,
            key_opt=None,
            std_period = 'full',
            proxy_id='mann_etal1999', \
            n_extrap=1, \
            select_on_id=True, \
            replace_pcs=None, \
            ppcs = None, \
            mann_etal1999_fixed_pc = True, \
            verbose=0, \
            lcal=79 ): 

    self.name = 'regresser'
    self.n_extrap=n_extrap

    self.ee = {}
    self.start = xrange[0]
    self.end_year = xrange[1]
    self.proxy_id  = proxy_id
    self.ncfile = ncfile
    self.lcal = lcal
    self.time_res = False

    self.nc = cdms.open( self.ncfile, 'r' )
    keys = self.nc.variables.keys()
    keys.sort()

    if key_list != None:
      nnf=0
      for k in key_list:
        if k not in keys:
          print k, ' not found in keys'
          nnf +=1
        if nnf != 0:
          print keys
          self.nc.close()
          raise 'error'
      keys = key_list
    else:
      keys = basic_utils.xx_where( \
         lambda x: self.nc.variables[x].standard_name == 'proxy', keys, extract=True )
      if len (keys) == 0:
        print ' no proxies found in: ',self.ncfile
        self.nc.close()
        raise 'error'

      if select_on_id:
        keys = basic_utils.xx_where( \
           lambda x: self.nc.variables[x].collection_id == proxy_id, keys, extract=True )
        if len (keys) == 0:
          print 'no proxies matching id %s found in %s ' % (proxy_id, self.ncfile)
          self.nc.close()
          raise 'error'

      keys = basic_utils.xx_where( \
         lambda x: (self.nc.variables[x].start[0] <= self.start) and \
            (self.nc.variables[x].end[0] >= self.end_year-n_extrap ), keys, extract=True )

      if proxy_id == 'mann_etal1999':
        if mann_etal1999_fixed_pc:
          keys.pop( keys.index( 'mbh99_13' ) )
        else:
          keys.pop( keys.index( 'mbh99_01' ) )
      elif proxy_id == 'mann_etal1998':
        sect_list = ['VAGANOV_SOVIET_TREEL', 'ITRDB-NORTH_AMERICA', \
                    'Stahle_swm_late', 'Stahle_swm_early' ]
        keys = basic_utils.xx_where( \
         lambda x: self.nc.variables[x].section not in sect_list, \
             keys, extract=True )

      if len (keys) == 0:
        print 'no proxies matching id %s and starting before %s found in %s ' % (proxy_id, self.start, self.ncfile)
        self.nc.close()
        raise 'error'

    if verbose > 1:
      print 'keys extracted:',keys
    self.keys = keys

    nproxy = len( keys )
    ny = self.end_year + 1 - self.start
    self.predictor = multiarray.zeros( (nproxy,ny), 'f' )
    self.predictor_raw = multiarray.zeros( (nproxy,ny), 'f' )
    self.predictor_mean = multiarray.zeros( (nproxy), 'f' )
    self.predictor_var = multiarray.zeros( (nproxy), 'f' )
    tax = self.nc.getAxis( 'time' ).getValue()
    i0 = self.start - tax[0]
    ik=0

    if std_period == 'cal':
      n_right=lcal
    elif std_period == 'full':
      n_right=-1
    else:
      print 'std_period should be cal or full'
      raise 'error'

    if verbose > 1:
      print std_opt, lcal
    self.meta_dict = {}
    for k in keys:
      mdict = {}
      for at in self.nc.variables[k].listattributes():
        mdict[at] = self.nc.variables[k].getattribute( at )

      self.predictor[ik,:], self.predictor_mean[ik], self.predictor_var[ik] =  \
           self.standardise( \
              self.nc.variables[k].getValue().tolist()[i0:i0+ny], \
              opt=std_opt, n_right=n_right )
      self.predictor_raw[ik,:] =  \
              self.nc.variables[k].getValue().tolist()[i0:i0+ny]
      ik+=1
      self.meta_dict[k] = mdict
      
    self.keys = keys
    self.l1 = nproxy
    self.nc.close()
##
## recalculated mann et al, 1998, 1999 proxy pcs
##
    if ppcs != None:
      if replace_pcs == None:
        kks = range(3)
      else:
        kks = []
        for p in replace_pcs:
          kks.append( self.keys.index( p ) )

      nc = cdms.open( data_dir + 'nc/mitrie_new_proxy_pcs_%4.4i_v01.nc' % self.start, 'r' )
      k1=0
      for k in kks:
          v2 = nc.variables[ ppcs[k1] ].getValue()
          self.predictor[k,:], self.predictor_mean[k], self.predictor_var[k] =  \
                    self.standardise( v2, opt=std_opt, n_right=n_right )
          self.predictor_raw[k,:] =  v2
          k1+=1
      nc.close()

############################################
### predictand stuff.

    self.load_predictand( )
    if proxy_id == 'mann_etal1999':
      for k in range(3):
        ss = sum( self.predictor[k,-self.lcal:]*self.predictand )
        if ss < 0:
          self.predictor[k,:] = - self.predictor[k,:]

  def run(self,regress_opt='invr'):
    self.regress_opt = regress_opt
    if regress_opt == 'invr':

      self.regress_coeff()
##
## Get the reconstruction
##
      self.calc_recon()
    else:
      self.get_composite()
      self.regress_composite( opt=regress_opt)
    self.std_err, self.ndf1, self.ndf2 = self.residuals_pp()

  def save(self,file='test'):
    oo = shelve.open( file )
    oo['temp'] = self.predicted_temp
    oo['gg'] = self.gg
    oo['predictor'] = self.predictor
    oo['predictor_raw'] = self.predictor_raw
    oo['keys'] = self.keys

    data_dict = {}
    for k in range( len(self.keys) ):
      data_dict[self.keys[k]] = self.predictor[k]
    oo['data_dict'] = data_dict
    oo['meta_dict'] = self.meta_dict

    if hasattr( self, 'ac' ):
      oo['ac'] = self.ac
      oo['std_err'] = self.std_err
      oo['ndf'] = [self.ndf1, self.ndf2]
      oo['cp'] = self.ac
      oo['gg'] = self.gg
    oo.close()

#####################################################################
## get predictands: temperature principal components or temperature
#####################################################################
  def load_predictand( self ):

      inst = cdms.open( data_dir + 'nc/mitrie_instrumental_v01.nc', 'r' )
      nht = inst.variables['nh'].getValue().tolist()
      y_cru = inst.getAxis('time').getValue()
      inst.close()
      self.predictand = multiarray.zeros( (self.lcal,), 'd' )
      pd0 = self.end_year - self.lcal + 1 - int( y_cru[0]  + 0.0001)
      self.predictand[:] = nht[pd0:pd0+self.lcal]
      self.predictand_mean = sum( self.predictand)/self.lcal
      self.predictand = self.predictand - self.predictand_mean


#################################################
## currently only programmed for opt = 'mbh'
#################################################
## calculates x Y^t (Y Y^t)^{-1}
## where:
## x = self.predictor in the calibration period: i.e. the temperature pcs.
## Y = self.predictand: i.e. the proxies.
###################################################
  def regress_coeff( self ):

      ac = self.predictor[:,-self.lcal:]
      if self.time_res:
          print 'smoothing predictand in inverse regression'
          sp = basic_utils.smooth( self.predictand, self.time_res, pad=1 )
          self.gg = dot( ac, sp )/dot( sp, sp )
      else:
          sp = self.predictand
          self.gg = dot( ac, transpose( sp ) )/dot( sp, sp )

#################################################
###################################################
  def get_composite( self, verbose=0 ):

## composite and centre on the calibration period.
    res = self.standardise( \
               sum( self.predictor, axis=0 )/self.l1, \
              opt='cen', n_right=self.lcal )
    if verbose > 1:
      print 'getting composite::',res[1],res[2]
      print len(res[0])
      print res[0][0:10]
    self.composite = array( res[0] )

  def regress_composite( self, opt='cols' ):

    cc = dot( self.composite[-self.lcal:], self.composite[-self.lcal:] )
    if self.time_res:
      print 'smoothing predictand in variance calculation'
      sp = basic_utils.smooth( self.predictand, self.time_res )
      self.pp =  dot( sp, sp )*len(self.predictand)/len(sp)
    else:
      self.pp =  dot( self.predictand, self.predictand ) 

    if opt == 'cols':
      self.gg = dot( self.composite[-self.lcal:], self.predictand )/cc
      self.predicted_temp = self.gg*self.composite
    elif opt == 'cvm':
      self.gg = sqrt( self.pp/cc )
      
      self.predicted_temp = self.gg*self.composite
    else:
      print 'option ',opt,' not available'
      raise 'error in regress_composite'

    self.residuals = self.predictand - self.predicted_temp[-self.lcal:]


  def residuals_pp( self ):

    lch = self.lcal/2
    self.ac = multiarray.zeros( (2,lch), 'f' )
    for i in range( self.lcal/2 ):
      self.ac[0,i] =  vdot( self.residuals[:lch],
                           self.residuals[i:i+lch] )/lch 
      if i != 0:
        self.ac[1,i] =  vdot( self.residuals[:-i],
                           self.residuals[i:] )/(self.lcal-i) 
      else:
        self.ac[1,i] = self.ac[0,i]

    self.ac[0,:] = self.ac[0,:]/self.ac[0,0]
    self.ac[1,:] = self.ac[1,:]/self.ac[1,0]

    v0 =  vdot( self.residuals, self.residuals )/self.lcal
    v1 =  vdot( self.residuals[1:], self.residuals[:-1] )/(self.lcal-1)
    v2 =  vdot( self.residuals[2:], self.residuals[:-2] )/(self.lcal-2)
    v3 =  vdot( self.residuals[3:], self.residuals[:-3] )/(self.lcal-3)
    std_err = sqrt( v0 )
    ndf1 = self.lcal*( 1.-v1/v0 )
    ndf2 = self.lcal*( 1.-sum( [v1/v0, v2/v1, v3/v2] )/3. )
    x = self.predicted_temp[-self.lcal:]
    u0 =  vdot( self.predictand, self.predictand )/self.lcal
    u1 =  vdot( self.predictand[1:], self.predictand[:-1] )/(self.lcal-1)

    tau_d = 1. - self.ac[0,1]
    tau_i = sum( self.ac[0,:] )/lch
    ndf3 = int( self.lcal*( 1.-u1/u0 ) )
    alpha = u1/u0
    return (std_err, ndf1, ndf2 )


##########################################################
### standardise proxies -- either on whole time series
### or on last n_right values (as in Mann et al., 1998)
##########################################################
  def standardise( self, aa, n_right=-1, opt='std' ):
##
## n_right > 0:: standardise using latter end of series only.
##
    if self.n_extrap > 0:
      ii = basic_utils.xx_where( lambda x: x < -990., aa)
      if len(ii) > 0:
        print 'standardise:: filling'
        for i in ii:
          aa[i] = aa[ii[0]-1]

    if n_right > 0:
      if min( aa[-n_right:] ) < -990.:
        print 'untreated bad data in series to be standardised'
        raise 'error'
      ab = sum( aa[-n_right:] )/n_right
      if opt == 'mbh':
        av = sqrt( sum( map( lambda x: (x-ab)**2, mods.detrend_1d(aa[-n_right:]) ) )/n_right )
      elif opt == 'std':
        av = sqrt( sum( map( lambda x: (x-ab)**2, aa[-n_right:] ) )/n_right )
      elif opt == 'cen':
        av=1.
      else:
        print 'standardise option for part series should be one of cen, std, mbh'
      return map( lambda x: (x-ab)/av, aa ), ab, av
    else:
      if min( aa ) < -990.:
        print 'untreated bad data in series to be standardised'
        raise 'error'
      if opt == 'std':
        ab = sum( aa )/len(aa)
        av = sqrt( sum( map( lambda x: (x-ab)**2, aa ) )/len(aa) )
        return map( lambda x: (x-ab)/av, aa ), ab, av
      elif opt == 'cen':
        ab = sum( aa )/len(aa)
        return map( lambda x: x-ab, aa ), ab, 1.
      else:
        print 'standardise option for whole series should be one of cen, std'
        raise 'error'
      

##############################################################
###  create reconstruction: predicted values of predictands
#############################################################
### calculates:  hat(y) = (g^t g)^{-1} g^t x
#############################################################
  def calc_recon(self):
######################
## scalar regression
######################
      self.pp =  0

      self.predicted_temp = \
           dot( transpose(self.gg), self.predictor )/dot( self.gg, self.gg )
      self.residuals = self.predictand - self.predicted_temp[-self.lcal:]

  def show(self):
    for k in self.keys:
      print k

from Numeric import *
import random
#*  This program simulates fractional Gaussian noise or fractional          */
#*  Brownian motion using the Hosking method.                               */
#*  The C-package Ranlib is used, available via Netlib                      */
#*  (http://www.netlib.org).                                                */

#*  Reference:                                                              */
#*  J.R.M. Hosking (1984),                                                  */
#*  Modeling persistence in hydrological time series using fractional       */
#*  brownian differencing,                                                  */
#*  Water Resources Research, Vol. 20, pp. 1898--1908.                      */
#*
#* Uses Levinson-Durbin regression to calculate partial correlations

## based on c code by Ton Dieker
#*  Centre of Mathematics and Computer Science (CWI) Amsterdam              */
#*  April 2002                                                              */
#*  ton@cwi.nl                                                              */

class h:

  def __init__( self, cov, set_seed=None, seed=None, \
             start_state=None, ret_states=False, \
             verbose=False, init_only=False):

#
# Input: cov: covariance function
#        set_seed: [1|2|3]: 1: set system dependent seed,
#                           2: set seed using *seed* argument
#                           3: initialise using *start_state* argument
#                         else: no seed set
#            seed: used to initialise random number generator 
#         start_state: used to initialise if *set_seed* == 3
#         ret_states: return start and end states if True
#         verbose: print diagnostic messages if True
####################################################################
   
####### random number state initialisation #################
    if set_seed == 1:
      random.seed()
    elif set_seed == 2:
      random.seed(seed)
    elif set_seed == 3:
      random.setstate( start_state )
    if (set_seed != 3 ) and ret_states:
      start_state = random.getstate( )

    if init_only:
      return 1
############################################################

    lc = len(cov)

    phi = multiarray.zeros( (lc), 'd' )
    psi = multiarray.zeros( (lc), 'd' )
    vv = multiarray.zeros( (lc), 'd' )
    pp = multiarray.zeros( (lc*(lc-1)/2+1), 'd' )
  
    v = 1.
    phi[0] = 0.

    pp[0] = phi[0]
    vv[0] = v
    kp=0

    try:
     for i in range(1,lc):
      if i < lc:
        phi[i-1] = cov[i]
      else:
        phi[i-1] = 0.
      for j in range(i-1):
        psi[j] = phi[j]
        if i-j-1 < lc:
          phi[i-1] = phi[i-1] - psi[j]*cov[i-j-1]
    
      if verbose:
        print i, phi[i-1], psi[i-1], cov[i], v
      phi[i-1] = phi[i-1]/v
      if abs(phi[i-1]) > 1.:
        print 'can not proceed with algorithm -- '
        print 'i=',i,', phi[i-1]=',phi[i-1],', v=',v
        print 'cov=',cov
        raise 'error'

      for j in range(i-1):
        phi[j] = psi[j] - phi[i-1]*psi[i-j-2]

      v = v*(1-phi[i-1]*phi[i-1])
      vv[i] = v
    
      for j in range(i):
        pp[kp] = phi[j]
        kp+=1

     self.vv = vv
     self.pp = pp
     self.lc = lc
     self.rv=1
    except:
     print 'failed to initialise'
     self.rv=0

  def gen( self, len_out=None ):

    if len_out == None:
      len_out=lc

    output = multiarray.zeros( (len_out), 'd' )
    kp=0
    output[0] = random.gauss(0,1)
    for i in range( 1, min(len_out,self.lc) ):
      output[i] = 0
      for j in range(i):
        output[i] += self.pp[kp]*output[i-j-1]
        kp+=1
      output[i] = output[i] + sqrt(self.vv[i])*random.gauss(0,1)

    if len_out > self.lc:
      v = self.vv[-1]
      phi = self.pp[-self.lc:]
      for i in range(self.lc,len_out):
        output[i] = 0
        for j in range(self.lc):
          output[i] += phi[j]*output[i-j-1]
  
        output[i] = output[i] + sqrt(v)*random.gauss(0,1)
  
    return (1,output)

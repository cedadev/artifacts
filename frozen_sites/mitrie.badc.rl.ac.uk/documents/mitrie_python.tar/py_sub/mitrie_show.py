from config import work_dir, data_dir
import cdms, shelve, basic_utils, string
from Numeric import *
## from get_stuff_new.py ##

fpat = 'mr_%(proxy_set_id)s_%(start)s_%(regression_type)s_%(calibration_field)s' + \
       '_%(version)2.2i.%(proxy_option_code)2.2i.%(calibration_option_code)3.3i'

class gs:
  def __init__(self):
    self.proxy_option_code = 2
    self.start = 1000
    self.regression_type = 'invr'
    self.regression_type = 'cvm'
    self.calibration_field = 'nht'
    self.calibration_option_code = 1
    self.version = 1
    self.std_period = 'full'

    self.idlist = ['jones_etal1998','mann_etal1999', \
                'esper_etal2002','moberg_etal2005','hegerl_etal2006', \
                'union','union_85','union_85b']
    self.idlist = ['jbb','mbh','ecs','msh','hca','union','u85','u85b']

    for k in range(1,19):
        self.idlist.append( 'um%2.2i' % k )

  def run(self,ntest=10, nt2=None):

    mr = cdms.open( data_dir + 'nc/mitrie_new_reconstructions_v01.nc', 'r' )
    ii = cdms.open( data_dir + 'nc/mitrie_proxies_v01.nc', 'r' )
    mcr = cdms.open( data_dir + 'nc/mitrie_cited_reconstructions_v01.nc', 'r' )
    file = work_dir + 'shelves/recon_pp_%s' % ntest
    sh = shelve.open( file, 'r' )
    print file, type(sh)
    if nt2 != None:
      file2 = work_dir + 'shelves/recon_pp_%s' % nt2
      sh2 = shelve.open( file2, 'r' )

    inst = cdms.open( data_dir + 'nc/mitrie_instrumental_v01.nc', 'r' )
    nht = inst.variables['nh'].getValue()
    y_cru = inst.getAxis('time').getValue()
    inst.close()

    nhtb = sum( nht[0:124] )/124.
    nhtv = sqrt( sum( (nht[0:124]-nhtb)**2 ) )/124.
    self.nht_cen = nht - nhtb

    mcr_time = mcr.getAxis('time')
    mr_time = mr.getAxis('time')
    esp = mcr.variables['esper_etal2002'].getValue()
    espb = sum( esp[-138:-13] )/124.
    espv = sqrt( sum( (esp[-138:-13]-espb)**2 ) )/124.

    print nhtv, espv, 'scale factor::',nhtv/espv
    mcr.close()
    inst.close()

    print 'max instrumental temp:: %6.3f' % max( self.nht_cen )
    print ' id        max pre-indust [year], std dev., sig'
    for self.proxy_set_id in self.idlist:
      o2 = []
      id = fpat % self.__dict__
      vv = mr.variables[id].getValue()
      mpc = max( vv[0:856] )
      impc = vv.tolist().index( mpc )
      full_name = mr.variables[id].getattribute( 'name' )
      proxy_list = mr.variables[id].getattribute( 'proxy_list' )

      fmt, out = ('%16s, %7.4f [%s]', (self.proxy_set_id, mpc, impc+1000))

      if self.proxy_set_id in sh['idlist']:
        try:
          i0 = sh['idlist'].index(self.proxy_set_id)
          ss = sh['signifh'][i0]
          std_err = mr.variables[id].getattribute('std_err')[0]
          fmt +=  ', %7.4f,  %7.3f '
          out +=  ( std_err,ss[1] )
          o2 = [sh['sigh'][i0][95.0], sh['sig'][i0][95.0], sh['cc'][i0,-1], \
                  sh['cc'][-1,i0], sh['signifh'][i0][0], sh['signifh'][i0][1] ]
        except:
          print 'error reading from ',file
          print type(sh)
          return sh
      elif self.proxy_set_id in sh2['idlist']:
        i0 = sh2['idlist'].index(self.proxy_set_id)
        ss = sh2['signifh'][i0]
        std_err = mr.variables[id].getattribute('std_err')[0]
        fmt += ', %7.4f, (%7.3f) '
        out += (std_err,ss[1] )
      else:
        fmt += ', %s, %s '
        out += ( '--','--' )
        std_err = 1.

      ig0 = basic_utils.xx_where( lambda x: x > mpc, self.nht_cen )
      ig2 = basic_utils.xx_where( lambda x: x > mpc + 2.*std_err, self.nht_cen )
      ig3 = basic_utils.xx_where( lambda x: x > mpc + 3.*std_err, self.nht_cen )
      ig4 = basic_utils.xx_where( lambda x: x > mpc + 4.*std_err, self.nht_cen )
      if self.proxy_set_id == 'union':
        stuff = (ig0, ig2, ig3, ig4 )

      fmt += ': %4i, %4i, %4i; %4i, %4i'
      out += ( len(ig2), len(ig3), len(ig4) )
      if len(ig0) == 0:
        out += (-1,)
      else:
        out += ( y_cru[ig0[0]],)
      if len(ig2) == 0:
        out += (-1,)
      else:
        out += ( y_cru[ig2[0]],)

      omitted = ''
      if self.proxy_set_id == 'union':
        union_proxy_list = string.split(proxy_list, '; ')
      elif self.proxy_set_id[0:5] == 'union':
        plist = string.split(proxy_list, '; ')
        for p in union_proxy_list:
          if p not in plist:
            if omitted != '':
              omitted += '; '
            omitted += p
        fmt += ' -- %s'
        if len(omitted) < 32:
          out += (omitted,)
        else:
          out += (omitted[0:32],)
  
      print fmt % out
      try: 
        print '  %6.3f, %6.3f, %6.3f, %6.3f, %6.3f, %6.3f' % tuple( o2 )
      except:
        action = None

    print 'years above union max:'
    print map( lambda x: int(y_cru[x]), stuff[0] )
    print 'years above union max + 2sig:'
    print map( lambda x: int(y_cru[x]), stuff[1] )
    print 'years above union max + 3sig:'
    print map( lambda x: int(y_cru[x]), stuff[2] )
    print 'years above union max + 4sig:'
    print map( lambda x: int(y_cru[x]), stuff[3] )

    tl = ['mbh','msh','ecs','jbb','hca','union']
    c4 = multiarray.zeros( (6,6) , 'f' )
    c4l = multiarray.zeros( (6,6) , 'f' )
    c4h = multiarray.zeros( (6,6) , 'f' )
    j1 = 0
    for t1 in tl:
      i1 = sh['idlist'].index(t1)
      j2 = 0
      for t2 in tl:
        i2 = sh['idlist'].index(t2)
        c4[j1,j2] = sh['cc'][i1,i2]
        c4[j2,j1] = sh['cc'][i2,i1]
        c4l[j1,j2] = sh['cclo'][i1,i2]
        c4l[j2,j1] = sh['cclo'][i2,i1]
        c4h[j1,j2] = sh['cchi'][i1,i2]
        c4h[j2,j1] = sh['cchi'][i2,i1]
        j2+=1
      j1 +=1
    print c4
    print 'low'
    print c4l
    print 'high'
    print c4h
    mr.close()
    ii.close()
    sh.close()

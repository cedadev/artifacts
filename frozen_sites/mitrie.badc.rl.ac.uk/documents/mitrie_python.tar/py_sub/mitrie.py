import mitrie_regress,  mitrie_pp, mitrie_show, collect_mr, pnc

class r:

  def __init__(self):

    print 'class to generate all reconstructions etc'

    self.collector = collect_mr.r()
    self.shower = mitrie_show.gs()

  def all(self):
    self.reg('all')
    self.pp()
    self.show()

  def reg(self, opt='all'):
      self.regressor = mitrie_regress.regs()
      if opt =='all':
        self.regressor.run(opt='union')
        self.regressor.run(opt='cols')
        self.regressor.run(opt='mann_etal1999')
        self.regressor.run(opt='mann_etal1998')
      elif opt in ['union','cols','mann_etal1999','mann_etal1998']:
        self.regressor.run(opt=opt)
      else:
        raise 'reg: option no recognised'

  def pp( self, opt='all', ntest=10000, nt2=10 ):
## collect output  from various shelves into netcdf file ##
    if opt in ['all','collect']:
      self.collector.run()
      self.collector.run(start=1400)
## do some post processing ##
    if opt in ['pp','all']:
      self.pprocessor = mitrie_pp.ma(nyear=986)
      self.pprocessor.run(ntest=ntest)
      if nt2 != None:
        self.pprocessor = mitrie_pp.ma(nyear=986, idlist_opt='all')
        self.pprocessor.run(ntest=nt2)

  def show( self, ntest=10000, nt2=10 ):
    sh = self.shower.run(ntest=ntest,nt2=nt2)
    print type(sh)
    return sh

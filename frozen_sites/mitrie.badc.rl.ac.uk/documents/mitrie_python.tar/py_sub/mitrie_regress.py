import do_regress
from config import work_dir, data_dir, union_klist

fpat = 'mr_%(proxy_set_id2)s_%(start)s_%(regression_type)s_%(calibration_field)s' + \
       '_%(version)2.2i.%(proxy_option_code)2.2i.%(calibration_option_code)3.3i'

mppc_pat = 'mppc%2.2i_%s_%4.4i_%s_%2.2i'

id2 = { 'jones_etal1998':'jbb', 'mann_etal1999':'mbh', \
        'esper_etal2002':'ecs', 'moberg_etal2005':'msh', 'hegerl_etal2006':'hca'}

class regs:

  def __init__(self):

    self.opt = 'union'
    self.proxy_option_code = 1
    self.regression_type = 'invr'
    self.calibration_field = 'nht'
    self.calibration_option_code = 1
    self.version = 1
    self.std_period = 'cal'

    self.std_opt = 'std'

    if self.proxy_option_code == 2:
      self.std_period = 'full'
    elif self.proxy_option_code == 3:
      self.std_opt='mbh'

    self.odir = work_dir + 'shelves/new_01/'

    self.plist = ['jones_etal1998','mann_etal1999', \
           'esper_etal2002','moberg_etal2005','hegerl_etal2006']

  def do_regs(self):
   if self.opt == 'cols':
    self.start=1000
    for self.proxy_set_id in self.plist:
      if self.proxy_set_id == 'hegerl_etal2006':
        end_year=1960
      else:
        end_year=1980
      self.proxy_set_id2 = id2.get( self.proxy_set_id, self.proxy_set_id )
      self.std_period = 'cal'
      if self.proxy_option_code == 2:
        self.std_period = 'full'
      elif self.proxy_option_code == 3:
        self.std_opt='mbh'

      lcal = end_year-1856
      r = do_regress.regresser( proxy_id = self.proxy_set_id, std_opt='std',
            lcal=lcal,  \
            std_period = self.std_period, \
            xrange=[1000,end_year] )
      r.run( self.regression_type )
      fname = fpat % self.__dict__
      print 'saving to ',self.odir + fname
      r.save(self.odir+fname )

   elif self.opt == 'mann_etal1998':
    self.start=1400
    end_year=1980
    sys = {1:1856,2:1902}
    for self.calibration_option_code in [1,2]:
      cal_start_year = sys[self.calibration_option_code]
      lcal = end_year-cal_start_year
  
      self.proxy_set_id = 'mann_etal1998'
      self.proxy_set_id2 = 'mbh98'
      r = do_regress.regresser( \
          ncfile=data_dir + 'nc/mann_etal1998_x.nc',\
          xrange=[1400,end_year],proxy_id='mann_etal1998', select_on_id=False, \
          lcal=lcal,  \
          std_period = self.std_period )
          
      r.run( self.regression_type )
      fname = fpat % self.__dict__
      print 'xz: saving to ',self.odir + fname
      r.save(self.odir+fname )

      self.proxy_set_id2 = 'mbh98x'
      poc = self.proxy_option_code
      for pad_option in [0,1]:
        for std_opt in ['mbh','mbhl','mbhx','std','cen']:
          
          ppcs = [ mppc_pat % ( 1, 'itrdb_namer', self.start, std_opt, pad_option ),
                   mppc_pat % ( 2, 'itrdb_namer', self.start, std_opt, pad_option ),
                   mppc_pat % ( 1, 'stahle_swm', self.start, std_opt, pad_option ) ]

          r = do_regress.regresser( \
              ncfile=data_dir + 'nc/mann_etal1998_x.nc',\
              lcal=lcal,  \
              std_period = self.std_period, \
              xrange=[1400,end_year],proxy_id='mann_etal1998', select_on_id=False, \
              ppcs = ppcs, \
              replace_pcs=['NorthAmericaITRDB_pc01','NorthAmericaITRDB_pc02','StahleSouthwest_pc01'] )
              
          self.proxy_option_code = poc + 10*pad_option
          r.run( self.regression_type )
          fname = fpat % self.__dict__
          fname = fname + '_' + std_opt
          print 'xz: saving to ',self.odir + fname
          r.save(self.odir+fname )
      self.proxy_option_code = poc

   elif self.opt == 'mann_etal1999':
    self.start=1000
    self.proxy_set_id = 'mann_etal1999'
    pad_option = 0
    self.proxy_set_id2 = 'mbhx'
    end_year=1980
    lcal = end_year-1856
    self.start = 1000
  
    for std_opt in ['mbh','mbhl','mbhx','std','cen']:
      ppc_file = 'itrdb_namer_pc_1000_%s.nc' % std_opt
      ppcs = []
      for kmo in range(1,4):
        ppcs.append( mppc_pat % ( kmo, 'itrdb_namer', self.start, std_opt, pad_option ))

      r = do_regress.regresser( proxy_id = self.proxy_set_id, std_opt='std',
          lcal=lcal,  \
          std_period = self.std_period, \
          xrange=[1000,end_year], \
          ppcs = ppcs )
          
      r.run( self.regression_type )
      fname = fpat % self.__dict__
      fname = fname + '_' + std_opt
      print 'xz: saving to ',self.odir + fname
      r.save(self.odir+fname )

    self.proxy_set_id2 = id2.get( self.proxy_set_id, self.proxy_set_id )
    for tag in ['pc','ff']:
      nextrap = 0
      if tag == 'ff':
        nextrap = 10
      if tag == 'pc':
        fixed_pc=False
      else:
        fixed_pc=True

      r = do_regress.regresser( proxy_id = self.proxy_set_id, std_opt='std',
          lcal=lcal,  \
          std_period = self.std_period, \
          n_extrap = nextrap, \
          mann_etal1999_fixed_pc=fixed_pc, 
          xrange=[1000,end_year] )
          
      r.run( self.regression_type )
      fname = fpat % self.__dict__
      fname = fname + '_' + tag
      print 'xx: saving to ',self.odir + fname
      r.save(self.odir+fname )

   elif self.opt == 'union':
      self.start=1000
##
## list of proxies used for reconstruction up to 1985.
##
      klist_85 = ['mcslo_002', 'mcslo_004', 'mcslo_009', 'mcslo_010',  \
                  'mcshi_004', 'mcshi_005', 'ecs_002', 'ecs_009', 'ecs_012', \
                  'jbb_002' ]

      klist = union_klist

      r = do_regress.regresser( key_list=klist, std_opt='std', lcal=124,  \
          std_period = self.std_period )
          

      r.run( self.regression_type )
      self.proxy_set_id = 'union'
      self.proxy_set_id2 = 'union'
      fname = fpat % self.__dict__
      print 'saving to ',self.odir + fname
      r.save(self.odir+fname )

      klist_lo = ['mcslo_002', 'mcslo_004', 'mcslo_009', 'mcslo_010', 'mcslo_011', \
           'jbb_010', 'mbh99_08', 'mbh99_11', 'mbh99_12']

      klist_hi = ['jbb_001', 'jbb_002', 
           'mcshi_001', 'mcshi_002', 'mcshi_005', \
           'ecs_002', 'ecs_009', 'ecs_011', 'ecs_012', \
           'mbh99_08']

      r = do_regress.regresser( key_list=klist_lo, std_opt='std', lcal=124,  \
          std_period = self.std_period )
          
      r.run( self.regression_type )
      self.proxy_set_id2 = 'ulo'
      fname = fpat % self.__dict__
      print 'saving to ',self.odir + fname
      r.save(self.odir+fname )

      r = do_regress.regresser( key_list=klist_hi, std_opt='std', lcal=124,  \
          std_period = self.std_period )
          
      r.run( self.regression_type )
      self.proxy_set_id = 'union_hi'
      self.proxy_set_id2 = 'uhi'
      fname = fpat % self.__dict__
      print 'saving to ',self.odir + fname
      r.save(self.odir+fname )

      r = do_regress.regresser( key_list=klist_85, std_opt='std', lcal=129,  \
          std_period = self.std_period, xrange=[1000,1985] )
          
      r.run( self.regression_type )
      self.proxy_set_id = 'union_85'
      self.proxy_set_id2 = 'u85'
      fname = fpat % self.__dict__
      print 'saving to ',self.odir + fname
      r.save(self.odir+fname )

      r = do_regress.regresser( key_list=klist_85, std_opt='std', lcal=124,  \
          std_period = self.std_period, xrange=[1000,1980] )
          
      r.run( self.regression_type )
      self.proxy_set_id = 'union_85b'
      self.proxy_set_id2 = 'u85b'
      fname = fpat % self.__dict__
      print 'saving to ',self.odir + fname
      r.save(self.odir+fname )

      kk = 0
      for kl in klist:
        kk+=1
        klm = klist[:]
        klm.remove(kl)
        r = do_regress.regresser( key_list=klm, std_opt='std', lcal=124,  \
          std_period = self.std_period, xrange=[1000,1980] )
          
        r.run( self.regression_type )
        self.proxy_set_id = 'union_m%2.2i' % kk
        self.proxy_set_id2 = 'um%2.2i' % kk
        fname = fpat % self.__dict__
        print 'saving to ',self.odir + fname
        r.save(self.odir+fname )

  def run(self,  opt='union', codes=[1,2], types=['cvm','invr'] ):
    self.opt = opt
    for self.proxy_option_code in codes:
        for self.regression_type in types:
          self.do_regs()

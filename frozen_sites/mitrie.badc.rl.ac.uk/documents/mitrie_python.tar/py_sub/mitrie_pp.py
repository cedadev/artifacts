import shelve, cdms
from Numeric import *
from config import work_dir, data_dir
import basic_utils, stat_s
## formerly mitrie_nc_utils.py ##

fpat = 'mr_%(proxy_set_id)s_%(start)s_%(regression_type)s_%(calibration_field)s' + \
       '_%(version)2.2i.%(proxy_option_code)2.2i.%(calibration_option_code)3.3i'

odir = work_dir + 'shelves/new/'

ss = stat_s.stat_sig()

class ma:

  def __init__( self, idlist=None, nyear=986, proxy_option_code = 2, start = 1000,  \
        regression_type = 'cvm', calibration_field = 'nht', \
        idlist_opt=[], \
        extend=0, \
        calibration_option_code = 1, version = 1 ): 

    if idlist_opt == 'all':
      idlist_opt = ['85','m','x']
    elif type( idlist_opt) == type('x'):
      idlist_opt = [idlist_opt,]

    if idlist == None:
      idlist = ['jones_etal1998','mann_etal1999', \
                'esper_etal2002','moberg_etal2005','hegerl_etal2006', \
                'union']
      idlist = ['jbb','mbh','ecs','msh','hca','union']
      if '85' in idlist_opt:
         idlist += ['u85','u85b']

      if 'm' in idlist_opt:
        for k2 in range(1,19):
          idlist.append( 'um%2.2i' % k2 )

    fnl = []
    for proxy_set_id in idlist:
      fnl.append( fpat % locals() )

    if 'x' in idlist_opt:
      proxy_set_id = 'mbh'
      fname = fpat % locals()
      for tag in ['_ff','_pc']:
        idlist.append( proxy_set_id + tag )
        fnl.append( fname + tag )

      proxy_set_id = 'mbhx'
      fname = fpat % locals()
      for tag in ['_mbh','_cen','_std']:
        idlist.append( proxy_set_id + tag )
        fnl.append( fname + tag )

    self.idlist = idlist
    ngr = len(self.idlist) + 1
    self.l1 = ngr
    self.l2 = nyear
    self.aa = multiarray.zeros( (self.l1,self.l2), 'f' )
    self.std_err = multiarray.zeros( (self.l1), 'f' )
    self.aa[:,:] = -999.

    nc = cdms.open( data_dir + 'nc/mitrie_new_reconstructions_v01.nc', 'r' )

    k=0
    for fname in fnl:
      if fname in nc.variables.keys():
        ll = len( nc.variables[fname].getValue() )
        self.aa[k,:ll] = nc.variables[fname].getValue()
        self.std_err[k] = nc.variables[fname].attributes['std_err'][0]
        k+=1
      else:
          print fname,' not found'
          for a in nc.variables.keys():
            print a
          raise 'error'
      
    nc.close()

    nc = cdms.open( data_dir + 'nc/mitrie_instrumental_v01.nc', 'r' )
    nht         = nc.variables['nh'].getValue().tolist()
    print len(nht), len( self.aa[ngr-1,856:] )
    nhoff = 25 + 981 - nyear
    self.aa[ngr-1,856:] = nc.variables['nh'].getValue().tolist()[-150:-nhoff]
    nc.close()

  def filter( self, nn ):
    l1 = len(self.aa)
    l2 = len(self.aa[0])
    l2b = l2 - 2*nn
    self.hi = multiarray.zeros( (l1, l2b), 'f' )
    self.lo = multiarray.zeros( (l1, l2b), 'f' )

    for k in range( l1 ):
      ii = basic_utils.xx_where( lambda x: x > -990., self.aa[k,:] )
      rw = 1./float(2*nn+1 )
      for j in range(len(ii)-2*nn):
        i = ii[j]
        self.lo[k,i] = sum( self.aa[k,i:i+2*nn+1] )*rw
        self.hi[k,i] = self.aa[k,i+nn] - self.lo[k,i]


  def cross_corr(self):
    self.cc = multiarray.zeros( (self.l1,self.l1), 'f' )
    for i in range( self.l1-1 ):
      for j in range( i+1, self.l1):
        ii = basic_utils.xx_where( lambda x: (x[0] > -990.) and (x[1] > -990.), \
                  map( lambda u,v: (u,v), self.aa[i,:], self.aa[j,:] ) , \
                  extract=1, dimension=0)
        ib = sum(ii, axis=0)/len(ii)
        tt = array( range(len(ii)), 'f' ) - 0.5*(len(ii)-1.)
        ss = 0.
        s1 = 0.
        s2 = 0.
        t1 = 0.
        t2 = 0.
        ts = 0.
        ix = 0
        for ti in ii:
          ss += (ti[0]-ib[0])*(ti[1]-ib[1])
          s1 += (ti[0]-ib[0])**2
          s2 += (ti[1]-ib[1])**2
          t1 += (ti[0]-ib[0])*tt[ix]
          t2 += (ti[1]-ib[1])*tt[ix]
          ts += tt[ix]**2
          ix += 1
        ss = ss/sqrt(s1*s2)
        t1 = t1/ts
        t2 = t2/ts
        self.cc[i,j] = ss
        ss = 0.
        s1 = 0.
        s2 = 0.
        print i,j, len(ii), len(ii[0]) , t1, t2
        for ix in range( len(ii)):
          ti = ii[ix]
          tti = tt[ix]
          ss += (ti[0]-ib[0]-tti*t1)*(ti[1]-ib[1]-tti*t2)
          s1 += (ti[0]-ib[0]-tti*t1)**2
          s2 += (ti[1]-ib[1]-tti*t2)**2
        ss = ss/sqrt(s1*s2)
        self.cc[j,i] = ss
    self.cc_info ='cc[i,j]: correlation (j>i) and detrended correlation (j<i)'

  def cross_corr2(self, aa):
    l1 = len(aa)
    l2 = len(aa[0])
    cc = multiarray.zeros( (l1,l1), 'f' )
    for i in range( l1-1 ):
      for j in range( i+1, l1):
        ii = basic_utils.xx_where( lambda x: (x[0] > -990.) and (x[1] > -990.), \
                  map( lambda u,v: (u,v), aa[i,:], aa[j,:] ) , \
                  extract=1, dimension=0)
        ib = sum(ii, axis=0)/len(ii)
        tt = array( range(len(ii)), 'f' ) - 0.5*(len(ii)-1.)
        ss = 0.
        s1 = 0.
        s2 = 0.
        t1 = 0.
        t2 = 0.
        ts = 0.
        ix = 0
        for ti in ii:
          ss += (ti[0]-ib[0])*(ti[1]-ib[1])
          s1 += (ti[0]-ib[0])**2
          s2 += (ti[1]-ib[1])**2
          t1 += (ti[0]-ib[0])*tt[ix]
          t2 += (ti[1]-ib[1])*tt[ix]
          ts += tt[ix]**2
          ix += 1
        ss = ss/sqrt(s1*s2)
        t1 = t1/ts
        t2 = t2/ts
        cc[i,j] = ss
        ss = 0.
        s1 = 0.
        s2 = 0.
        print i,j, len(ii), len(ii[0]) , t1, t2
        for ix in range( len(ii)):
          ti = ii[ix]
          tti = tt[ix]
          ss += (ti[0]-ib[0]-tti*t1)*(ti[1]-ib[1]-tti*t2)
          s1 += (ti[0]-ib[0]-tti*t1)**2
          s2 += (ti[1]-ib[1]-tti*t2)**2
        ss = ss/sqrt(s1*s2)
        cc[j,i] = ss

    return cc

  def lag_corr(self, opt='max'):
    self.lc = multiarray.zeros( (self.l1,self.l2/2), 'f' )
    self.lcdtr = multiarray.zeros( (self.l1,self.l2/2), 'f' )
    self.lc[:,:] = -999.
    self.lcdtr[:,:] = -999.
    self.len_lag = multiarray.zeros( (self.l1), 'i' )
    for i in range( self.l1 ):
      ii = basic_utils.xx_where( lambda x: x > -990., \
                  self.aa[i,:], \
                  extract=1)
      ib = sum(ii)/len(ii)
      self.len_lag[i] = len(ii)/2
      tt = array( range(len(ii)), 'f' ) - 0.5*(len(ii)-1.)
      t1 = 0.
      ts = 0.
      ix = 0
      for ti in ii:
        t1 += (ti-ib)*tt[ix]
        ts += tt[ix]**2
        ix += 1
      t1 = t1/ts
      ss = 0.
      aa = map( lambda x: x-ib, ii )
      a2 = map( lambda x: ii[x]-ib-tt[x]*t1, range(len(ii)) )
      for j in range( len(ii)/2 ):
        ss=0
        s2=0
        if opt == 'half':
          for j2 in range( len(ii)/2 ):
            ss += aa[j2]*aa[j2+j]
            s2 += a2[j2]*a2[j2+j]
        else:
          lll = len(ii)-j
          for j2 in range( lll ):
            ss += aa[j2]*aa[j2+j]
            s2 += a2[j2]*a2[j2+j]
          ss = ss/lll
          s2 = s2/lll

        if j == 0:
          ss0 = ss
          s20 = s2
          self.lc[i,j] = 1.
          self.lcdtr[i,j] = 1.
        else:
          self.lc[i,j] = ss/ss0
          self.lcdtr[i,j] = s2/s20

  def get_sig(self,ntest=10):

### first order markov
    self.sig = []
    self.sigh = []
    self.signif = []
    self.signifh = []
    self.oo = []
    self.ooh = []
    alpha_nht = self.lcdtr[-1,1]/self.lcdtr[-1,0]
    temp_lc = self.lcdtr[-1,:self.len_lag[-1]]
    temp_lc = self.lcdtr[-1,:31]
    for i in range( self.l1-1 ):
      lcal = 125
      thlc = self.lcdtr[i,:self.len_lag[i]]
      if self.idlist[i] == 'hegerl_etal2006':
        thlc = thlc[0:71]
        lcal = 105
      else:
        thlc = thlc[0:100]
      
      alpha_this = self.lcdtr[i,1]/self.lcdtr[i,0]
      rv, rdat = ss.monte_carlo( ss.r_squared, lcal, ntest, \
             test_sig=[99.,98.,95.], alpha=[alpha_this, alpha_nht] )
      if rv > 0:
        sig, lc2, oo = rdat
        self.sig.append( sig )
        oo.sort()
        ii = basic_utils.xx_where( lambda x: x < self.cc[i,-1], oo )
        i2 = basic_utils.xx_where( lambda x: x < self.cc[-1,i], oo )
        self.signif.append( (100.*ii[-1]/len(oo), 100.*i2[-1]/len(oo)) )
        self.oo.append( oo )
      else:
        print 'failed, fom, ',i

      rv, rdat = ss.monte_carlo( ss.r_squared, lcal, ntest, \
             test_sig=[99.,98.,95.], flc=[thlc,temp_lc] )
      if rv > 0:
        sig, lc2, oo = rdat
        self.sigh.append( sig )
        ii = basic_utils.xx_where( lambda x: x < self.cc[i,-1], oo )
        i2 = basic_utils.xx_where( lambda x: x < self.cc[-1,i], oo )
        self.signifh.append( (100.*ii[-1]/len(oo), 100.*i2[-1]/len(oo)) )
        self.ooh.append( oo )
      else:
        print 'failed, hosking, ',i

  def save( self, file='test' ):
    print 'trying to save to ',file
    oo = shelve.open( file, 'c' )
    oo['cc'] = self.cc
    oo['cclo'] = self.cclo
    oo['cchi'] = self.cchi
    oo['lc'] = self.lc
    oo['lcdtr'] = self.lcdtr
    oo['sig'] = self.sig
    oo['sigh'] = self.sigh
    oo['signif'] = self.signif
    oo['signifh'] = self.signifh
    oo['oo'] = self.oo
    oo['ooh'] = self.ooh
    oo['idlist'] = self.idlist
    oo.close()

  def read( self, file='test' ):
    oo = shelve.open( file, 'r' )
    self.cc = oo['cc']
    self.lc = oo['lc']
    self.lcdtr = oo['lcdtr']
    self.sig = oo['sig']
    self.sigh = oo['sigh']
    self.signif = oo['signif']
    self.signifh = oo['signifh']
    self.oo = oo['oo'] 
    self.ooh = oo['ooh'] 
    oo['idlist'] = self.idlist
    oo.close()

  def show(self):
    print self.idlist
    print self.cc
    sfmt = '(%4.2f, %4.2f)'
    ss = ''
    sh = ''
    for i in range( self.l1-1 ):
      ss += ' ' + sfmt % self.signif[i]
      sh += ' ' + sfmt % self.signifh[i]
    print ss
    print sh

  def run(self, ntest=10,file=None):
    self.cross_corr()
    self.filter( 10 )
    self.cchi = self.cross_corr2( self.hi )
    self.cclo = self.cross_corr2( self.lo )
    self.lag_corr()
    self.get_sig(ntest=ntest)
    self.show()
    if file == None:
      file = work_dir + 'shelves/recon_pp_%s' % ntest
    self.save(file=file)


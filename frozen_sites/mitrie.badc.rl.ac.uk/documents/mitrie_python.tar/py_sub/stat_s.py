#
###########################################################################
###########################################################################
#
# Utilities for proxy based temperature reconstructions
###########################################################################
from Numeric import *
import random
import hosking

##
############################################
## Do some statistical significance tests ##
############################################
class stat_sig:

  def __init__( self, aa=None ):
    if aa != None:
      if type( aa[0] ) in [ type( [] ), type( () ) ]:
        self.ntarg = len(aa)-1
        self.has_axis = 1
        self.axis = aa[0]
        self.len = len(aa[0])
        if self.ntarg == 1:
          self.data = aa[1]
        else:
          self.data = aa[1:]
      else:
        self.ntarg = 1
        self.has_axis = 0
        self.data = aa
        self.len = len(aa)
    else:
      self.ntarg = 0
      self.has_axis = 0
      self.data = None
      self.len = 0

  def stuff( self, ac ):

    td = 1./(1. - ac[1])
    ti = sum( ac )
    if ti < td:
      ti = td+1.

    tr = ti/td
    aa = 0.5*( 1 - (tr-1.)/sqrt( (tr+1.)**2 - .4 ) )
    print 'ti,td::',ti,td
    alp = (1./ti + 1./td - sqrt( (1./ti + 1./td)**2 - 4./ti**2 ) )*0.5
    bet = (1./ti + 1./td + sqrt( (1./ti + 1./td)**2 - 4./ti**2 ) )*0.5
    

    return (td,ti,alp,bet,aa)

    
  def get_subrange( self, bb, just='none', step=1, pert=0 ):

    if type( bb[0] ) in [ type( [] ), type( () ) ]:
      lb = len(bb[0])
      bax = bb[0]
      bdat = bb[1]
      has_baxis=1
    else:
      lb = len(bb)
      bdat = bb
      has_baxis=0

    if has_baxis == 1 and self.has_axis == 1:
      ii = compress( map( lambda x:x in self.axis,bax), range( lb ) )
      if len(ii) in [0,1]:
        print 'number of coincident data points = ',len(ii)
        print 'insufficient for statistical test'
        raise 'failed'
      jj = map( lambda x:self.axis.index(bax[x]), ii )
      x = map( lambda x:self.data[x], jj )
      y = map( lambda x:bdat[x], ii )
    else:
      raise 'not programmed for data without axis'

    if step != 1:
      ii = range(0,len(x),step )
      x = map( lambda a:x[a], ii )
      y = map( lambda a:y[a], ii )

    if pert == 1:
      xb = sum(x)/len(x)
      yb = sum(y)/len(y)
      x = map( lambda a:a-xb, x )
      y = map( lambda a:a-yb, y )

    return (x,y)

  def distrib( self, bb, range=None, bin_size=None, nbin=None, just='none', step=1, factor=1 ):
    x,y = self.get_subrange( bb, just=just, step=step )

    ee = map( lambda a,b:a-b*factor,x,y )

    std = sqrt( dot( ee, ee )/len(ee) )
    print 'standard deviation, min, max: ',std, min(ee), max(ee)

    if not range:
      range = [ min(ee), max(ee) ]
    if not nbin and not bin_size:
      nbin=10
    if nbin:
      bin_size = (range[1]-range[0])/float(nbin)
    else:
      nbin = int( (range[1]-range[0])/bin_size )
    print 'bin size: ',bin_size,', nbin: ',nbin

    dist = multiarray.zeros( (nbin,), 'f' )
    for e in ee:
      k = int( (e-range[0])/bin_size )
      k = min( [ max( [k,0] ), nbin-1 ] )
      dist[k] = dist[k] + 1

    dist = dist/(len(ee)*bin_size)
    return dist
  

  def r_squared( self, bb, x=None, just='none', step=1 ):
    if x:
      y = bb
    else:
      x,y = self.get_subrange( bb, just=just, step=step, pert=1 )

    xb = sum(x )/len(x)
    yb = sum(y )/len(y)
    for i in range( len(x) ):
      x[i] -= xb
      y[i] -= yb
    return dot(x,y)/sqrt( dot(x,x)*dot(y,y) )

###############################################################
## Wilcoxon signed rank test: returns a statistic which
## is N(0,1) distributed if the differences between the
## two series are random.
###############################################################
## assumes input data are independent
###############################################################
  def wilcoxon_sr( self, bb, x=None, just='none', step=1, factor=1. ):
    if x:
      y = bb
    else:
      x,y = self.get_subrange( bb, just=just, step=step )

    ee = map( lambda a,b:a-b*factor,x,y )
#
# sort by absolute value
    ee.sort(cmp=abs_cmp)
    tt = 0
    n = len(ee)
    for k in range(n):
      if ee[k] > 0.:
        tt += k

    z = (tt - n*(n+1)*0.25)/sqrt( n*(n+1)*(2*n+1)/24. )
    print 'wilcoxon: length compared: ',n
    return z


  def reduction_of_error( self, bb, x=None, just='none', \
        offset=0., factor=1., step=1, verbose=0 ):

    if x:
      y = bb
    else:
      x,y = self.get_subrange( bb, just=just, step=step )

    ee = map( lambda a,b:a-b*factor + offset,x,y )
    if verbose > 0:
      print 'reduction of error: length compared: ',len(ee)
    return 1.-dot(ee,ee)/dot(y,y)


  def rand_list( self, nn ):
    oo = []
    for k in range(nn):
      oo.append( random.gauss(0,1) )
    return oo

##
## first order markov process, with lag one correlation alpha [unchecked]
  def rand_fom( self, nn, alpha, do_exp=False ):

    if do_exp:
      alpha = exp( - alpha )

    aa = self.rand_list( nn )
    oo = [aa[0]]
    w = sqrt( 1.-alpha**2 )
    for a in aa[1:]:
      oo.append( alpha*oo[-1] + w*a )

    return array( oo, 'f' )

  def rand_som( self, nn, alpha, beta, do_exp=None ):

    aa = self.rand_list( nn )
    oo = [aa[0],aa[1]]
    for a in aa[2:]:
      oo.append( alpha*oo[-1] + beta*oo[-2] + a )

    return array( oo, 'f' )

  def rand_somb( self, nn, alpha, beta, aa, do_cos=None ):

    x = self.rand_fom( nn, alpha )
    y = self.rand_fom( nn, beta )
    if do_cos == None:
      oo =  aa*x + sqrt(1.-aa**2)*y
    else:
      z = self.rand_fom( nn, beta )
      oo = []
      for i in range( len(x) ):
        th = i*om
        oo.append( aa*x[i] + sqrt(1.-aa**2)*(y[i]*cos(th) + z[i]*sin(th) ) )

    return  oo

  def rand_tomb( self, nn, alpha, beta, gamma, aa, bb, om, do_cos=None ):

    x = self.rand_fom( nn, alpha )
    y = self.rand_fom( nn, beta )
    z = self.rand_fom( nn, gamma)
    if do_cos == None:
      oo =  aa*x + bb*y + sqrt(1.-aa**2-bb**2)*z
    else:
      z2 = self.rand_fom( nn, gamma )
      oo = []
      ccs = 1.-aa**2-bb**2
      if ccs < 0:
        print 'error in coefficient amplitude, rand_tomb'
        print 'aa,bb=',aa,bb,ccs
        raise 'fatal'
      else:
        cc = sqrt(ccs )
      for i in range( len(x) ):
        th = i*om
        oo.append( aa*x[i] + bb*y[i] + \
             cc*(z[i]*cos(th) + z2[i]*sin(th) ) )

    return  oo

  def monte_carlo( self, func, nn, nsamp, \
           test_val=None, test_sig=None, \
           flc=False, alpha=False ):

    oo = []
    lcopt=1
    if lcopt==0:
      lc = multiarray.zeros( (nn/2), 'f' )
    else:
      lc = multiarray.zeros( (nn), 'f' )
    print 'monte_carlo:: nn=',nn,', nsamp=',nsamp

    if flc:
      if len(flc)==2:
        hosk0 = hosking.h( flc[0], set_seed=2, seed=3141593 )
        if hosk0.rv == 0:
          print 'failed to initialise 0'
          raise 'error'
        hosk1 = hosking.h( flc[1], set_seed=2, seed=3141593 )
        if hosk1.rv == 0:
          print 'failed to initialise 1'
          raise 'error'
      else:
        hosk = hosking.h( flc, set_seed=2, seed=3141593 )
        if hosk.rv == 0:
          print 'failed to initialise 3'
          raise 'error'

    for k in range(nsamp):
       
      if flc:
        n1 = long( log( float( nn ) )/log( 2. ) )
        if len(flc)==2:
          rv, x = hosk0.gen( len_out=nn )
          if rv == 0: 
            return (0,'failed to generate x component')
          rv, y = hosk1.gen( len_out=nn )
          if rv == 0: 
            return (0,'failed to generate y component')
     
        else:
          rv, x = hosk.gen( len_out=nn )
          if rv == 0: 
            return (0,'failed to generate x component')
          rv, y = hosk.gen( len_out=nn )
          if rv == 0: 
            return (0,'failed to generate y component')

      elif alpha:
        if (type(alpha) in [type( () ),type( [])] ) and len(alpha) == 2:
          x = self.rand_fom(nn, alpha[0])
          y = self.rand_fom(nn, alpha[1])
        else:
          x = self.rand_fom(nn, alpha)
          y = self.rand_fom(nn, alpha)

      else:
        x = self.rand_list(nn)
        y = self.rand_list(nn)

      if x != None:
        oo.append( func( y, x=x ) )
        if lcopt==0:
          for i in range( nn/2 ):
            lc[i] = lc[i] + dot( x[i:i+nn/2], x[0:nn/2] )/float(nn/2)
        else:
          for i in range( nn ):
            lc[i] = lc[i] + dot( x[i:], x[0:nn-i] )/float(nn-i)
      else:
        return (-1,0 )

    lc = lc/nsamp

    oo.sort()
    if test_val:
      n=0
      for o in oo:
        if o < test_val:
          n+=1
      sig = float(n)/nsamp*100.
      return (1,(sig,lc,oo))
    elif test_sig:
      if type( test_sig ) in [ type( 0 ), type(0.) ]:
        return (1,( oo[int(nsamp*test_sig/100)], lc, oo ) )
      else:
        sig= {}
        for ts in test_sig:
          sig[ts] = oo[int(nsamp*ts*0.01)]
        return (1,(sig, lc, oo ))
    else:
      return (1,oo)

      

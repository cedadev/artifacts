import cdms, shelve, Numeric
from config import work_dir, data_dir

fpat = 'mr_%(proxy_set_id)s_%(start)s_%(regression_type)s_%(calibration_field)s' + \
       '_%(version)2.2i.%(proxy_option_code)2.2i.%(calibration_option_code)3.3i'

alist = ['proxy_option_code', 'start', 'regression_type', \
         'regression_type', 'calibration_field', 'calibration_option_code', \
         'version', 'std_period','proxy_list']

sdir = work_dir + 'shelves/new_01/'

class r:
  def __init__(self,start=1000):
    self.proxy_option_code = 1
    self.start = start
    self.regression_type = 'invr'
    self.regression_type = 'cvm'
    self.calibration_field = 'nht'
    self.calibration_option_code = 1
    self.version = 1

  def run(self,start=None):
    if start != None:
      self.start=start
    if self.start == 1000:
      self.run_1000()
    elif self.start == 1400:
      self.run_1400()

  def run_1000(self):
    self.nc = cdms.open( data_dir + 'nc/mitrie_new_reconstructions_v01.nc', 'w' )

    self.leny = 986
    self.time = cdms.createAxis( range(1000,1000+self.leny), id='time' )
    for self.proxy_option_code in [2,]:

      idlist = ['union','jbb','mbh', 'ecs','msh','hca', \
                'u85','u85b']

      for k in range(1,19):
        idlist.append( 'um%2.2i' % k )

      for self.regression_type in ['cvm','invr']:
        for self.proxy_set_id in idlist:
          fname = fpat % self.__dict__
          self.to_nc( sdir, fname )
    
        ### some variations on the mann_etal1999 reconstruction
        self.proxy_set_id = 'mbh'
        for tag in ['ff','pc']:
          fname = fpat % self.__dict__
          fname += '_' + tag
          self.to_nc( sdir, fname )
    
        self.proxy_set_id = 'mbhx'
        for opt in ['mbh','mbhx','std','cen']:
          fname = fpat % self.__dict__
          fname += '_' + opt
          self.to_nc( sdir, fname)

    sopt = False
    if sopt:
      self.regression_type = 'invr'
      self.proxy_option_code = 2
      for opt in ['mbh','mbhx','std','cen']:
          fname = fpat % self.__dict__
          fname += '_' + opt + '_s'
          self.to_nc( sdir, fname)
    
    self.nc.close()

  def run_1400(self):
    self.nc = cdms.open( data_dir + 'nc/mitrie_new_reconstructions_1400_v01.nc', 'w' )

    self.leny = 581
    self.time = cdms.createAxis( range(1400,1400+self.leny), id='time' )
    for self.calibration_option_code in [1,2]:
      for self.proxy_option_code in [1,2]:

        idlist = ['mbh98']

        for self.regression_type in ['cvm','invr']:
          for self.proxy_set_id in idlist:
            fname = fpat % self.__dict__
            print fname
            self.to_nc( sdir, fname )
    
    
      for self.proxy_option_code in [1,2,11,12]:
        self.proxy_set_id = 'mbh98x'
        for opt in ['mbh','mbhx','std','cen']:
          fname = fpat % self.__dict__
          fname += '_' + opt
          self.to_nc( sdir, fname)

    self.nc.close()

  def to_nc( self, path, fname ):
      if self.proxy_option_code == 1:
        self.std_period = 'cal'
      elif self.proxy_option_code == 2:
        self.std_period = 'full'

      try:
        ii = shelve.open( path + fname, 'r' )
      except:
        print 'failed to open::',path+fname
        raise 'file name error'
      print fname, ii['std_err']
      if len(ii['temp']) == self.leny:
        aa = Numeric.array( ii['temp'] )
      else:
        aa = Numeric.multiarray.zeros( (self.leny,), 'f' )
        aa[:len(ii['temp'])] = ii['temp'].tolist()
        aa[len(ii['temp']):] = -999.

      md = ii['meta_dict']
      keys = md.keys()
      keys.sort()
      self.proxy_list = md[keys[0]]['other_name']
      for k in keys[1:]:
        self.proxy_list += '; ' + md[k]['other_name']

      t = cdms.createVariable( aa, axes=[self.time], id = fname )
      t.attributes['standard_name'] = 'nh_temperature_reconstruction'
      t.attributes['name'] = fname
      t.attributes['std_err'] = ii['std_err']
      for a in alist:
        t.attributes[a] = self.__dict__[a]
      self.nc.write( t )
      ii.close()
